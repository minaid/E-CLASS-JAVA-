package Controller;

import java.time.LocalDate;
import java.util.Scanner;
import java.util.TimeZone;

import Model.Assignment;
import Model.Department;
import Model.Lesson;
import Model.Secretariat;
import Model.Student;
import Model.Teacher;
import Model.University;
import Model.User;

import java.time.LocalDate;

public class Main {

	public static void main(String[] args) {
		
		//University Piraeus=new University();
		//Piraeus.Create_Department("Computer Science");
		//Piraeus.get_Department_Byname("Computer Science").get_Users()[0].set_Username("Nikosmin"); //how to make a User a student?(maybe a function inside the User class that changes into Student?? User user=new Student();
		
		University Piraeus=CreateDefaultInstanceForTestPurposes();	
		Piraeus.LogIn();
	}


	static University CreateDefaultInstanceForTestPurposes()
	{
		University Piraeus=new University();
		Piraeus.Create_Department("Computer Science");
		Department dept=Piraeus.get_Department_Byname("Computer Science");
		dept.set_Secretariat(new Secretariat("Secretariat","CS","computer_science_secr@piraeus.gr","Computer Science Secretariat",false,false,true,dept,TimeZone.getTimeZone("0"),false));
		
		dept.Add_Student(new Student("stu_001","stu_001","GeorgeTestEmail@gmail.com","George","P",true,false,true,dept,TimeZone.getTimeZone("0"),false));
		dept.Add_Student(new Student("stu_002","stu_002","N.M@gmail.com","Nikos","M",true,false,true,dept,TimeZone.getTimeZone("0"),false));
		dept.Add_Student(new Student("stu_003","stu_003","G.M@gmail.com","Gerasimos","M",true,false,true,dept,TimeZone.getTimeZone("2"),false));
		dept.Add_Student(new Student("stu_004","stu_004","G.P@hotmail.com","Giannhs","Paralampos",false,false,false,dept,TimeZone.getTimeZone("0"),false));
		dept.Add_Student(new Student("stu_005","stu_005","T.T@yahoo.gr","Theodoros","Theodorou",false,true,true,dept,TimeZone.getTimeZone("1"),false));
		dept.Add_Student(new Student("admin","0","admin@yahoo.gr","Nick","Min",true,false,true,dept,TimeZone.getTimeZone("1"),false));

		dept.Add_Teacher(new Teacher("tea_001","tea_001","F02@comp_science_dept_piraeus.gr","Forean","Two",true,false,true,dept,TimeZone.getTimeZone("-2"),false));
		dept.Add_Teacher(new Teacher("tea_002","tea_002","GregDiam@comp_science_dept_piraeus.gr","Gregory","Diamantis",true,false,true,dept,TimeZone.getTimeZone("-2"),false));
		dept.Add_Teacher(new Teacher("tea_003","tea_003","SirGeo@comp_science_dept_piraeus.gr","Seirios","Georgiou",true,false,true,dept,TimeZone.getTimeZone("-2"),false));
		dept.Add_Teacher(new Teacher("tea_004","tea_004","GI@comp_science_dept_piraeus.gr","Giannis","Ioannou",true,false,true,dept,TimeZone.getTimeZone("-2"),false));
		dept.Add_Teacher(new Teacher("admin1","0","admin1@yahoo.gr","Nick1","Min1",true,false,true,dept,TimeZone.getTimeZone("-2"),false));

		Lesson lesson=new Lesson(dept.get_Teachers().get(0),"Diaxeirish Dedomenwn",dept,"Diaxeirish Dedomenwn, 1ou e3amhnou");
		dept.Add_Lesson(lesson);
		dept.get_Students().get(0).Enroll(lesson);
		dept.get_Students().get(1).Enroll(lesson);
		dept.get_Students().get(5).Enroll(lesson);

		lesson=new Lesson(dept.get_Teachers().get(4),"Texnologia Logismikou",dept,"Texnologia Logismikou, 1ou e3amhnou");
		dept.get_Teachers().get(4).set_Lessons(lesson);
		dept.Add_Lesson(lesson);
		dept.get_Students().get(2).Enroll(lesson);
		dept.get_Students().get(3).Enroll(lesson);
		dept.get_Students().get(4).Enroll(lesson);
		dept.get_Students().get(5).Enroll(lesson);
		
		lesson=new Lesson(dept.get_Teachers().get(1),"Prosarmostika Susthmata Didaskalias",dept,"Prosarmostika Susthmata Didaskalias, 2ou e3amhnou");
		dept.Add_Lesson(lesson);
		lesson.set_Assignment(new Assignment("Assignment Summer 2018","Do This and That", LocalDate.of(2018,4,1),LocalDate.of(2018,9,1),true,lesson));
		dept.get_Students().get(0).Enroll(lesson);
		dept.get_Students().get(1).Enroll(lesson);
		dept.get_Students().get(2).Enroll(lesson);
		dept.get_Students().get(3).Enroll(lesson);
		dept.get_Students().get(4).Enroll(lesson);
		dept.get_Students().get(5).Enroll(lesson);

		return Piraeus;
	}
}

//CONSTRUCTORS
//public Assignment(String Name,String Description,LocalDate Date_Starting,LocalDate Date_Ending,Boolean Status,Lesson lesson)
//public Student(String Username, String Password, String Email, String Name,String Surname, Boolean Notification_enabled, Boolean Is_Locked, Boolean Is_Active, Department BelongToDepartment,TimeZone GMT)
//public Teacher(String Username, String Password, String Email, String Name, String Surname, Boolean Notification_enabled, Boolean Is_Locked, Boolean Is_Active, Department BelongToDepartment,TimeZone GMT)
//public Secretariat(String Username, String Password, String Email, String Name,Boolean Notification_enabled, Boolean Is_Locked, Boolean Is_Active, Department BelongToDepartment,TimeZone GMT) 
//public Lesson(Teacher teacher,String Name,Department BelongToDepartment, String Description)