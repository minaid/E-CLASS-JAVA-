package Model;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.TimeZone;

public class Student extends User {

	public List<Student> Friends;
	public String Surname;
	public List<Lesson> Lessons;
	public String Student_Title;
	public int AM_Number;
	public Date DOB;
	public String[] Skills;
	public int Skills_Counter;
	public String[] Languages;
	public int Languages_Counter;
	public String Education;
	public Assignment[] Assignments;
	public int Assignments_Counter;
	
	public Student[] Friends_Request;   //It can also be implemented with a Friend Request Class
	public int Friends_Request_Counter;
	public Boolean[] Pending_Requests;
	public int Pending_Requests_Counter;
	
//Constructor
//------------------------------------------------------------------------------------------------------------------------------
	public Student(String Username, String Password, String Email, String Name,String Surname,
			Boolean Notification_enabled, Boolean Is_Locked, Boolean Is_Active, Department BelongToDepartment,
			TimeZone GMT, Boolean Is_Online) {
		super(Username, Password, Email, Name, Notification_enabled, Is_Locked, Is_Active, BelongToDepartment, GMT, Is_Online);
		Friends=new ArrayList<Student>();
		Lessons=new ArrayList<Lesson>();
		this.Surname=Surname;
		// TODO Auto-generated constructor stub
	}
//------------------------------------------------------------------------------------------------------------------------------

//Abstract Method
//------------------------------------------------------------------
	@Override
	void Temp() {
		// TODO Auto-generated method stub
	}
//------------------------------------------------------------------
	
	
//set methods
//------------------------------------------------------------------------------------------------------
	public void set_Surname(String Surname){	
		this.Surname=Surname;
	}
	
	public void set_Friends(Student friend){	
		this.Friends.add(friend);
	}
	
	public void set_Lessons(Lesson lesson){	
		this.Lessons.add(lesson);
	}
	
	public void set_Student_Title(String Student_Title){	
		this.Student_Title=Student_Title;
	}
	
	public void set_AM_Number(int AM_Number){	
		this.AM_Number=AM_Number;
	}
	
	public void set_DOB(Date DOB){	
		this.DOB=DOB;
	}
	
	public void set_Skills(String skill){	
		this.Skills[this.Skills_Counter]=skill;
		this.Skills_Counter=this.Skills_Counter+1;
	}
	
	public void set_Languages(String language){	
		this.Languages[this.Languages_Counter]=language;
		this.Languages_Counter=this.Languages_Counter+1;
	}
	
	public void set_Education(String Education){	
		this.Education=Education;
	}
	
	public void set_Assignments(Assignment assignment){	
		this.Assignments[this.Assignments_Counter]=assignment;
		this.Assignments_Counter=this.Assignments_Counter+1;
	}
//---------------------------------------------------------------------------------------------------------


//get methods
//---------------------------------------------------------------------------------------------------------
	public	List<Student> get_Friends(){
		return Friends;
	}
	
	public String get_Surname() {
		return Surname;
	}
	
	public List<Lesson> get_Lessons(){
		return Lessons;
	}
	
	public String get_Student_Title() {
		return Student_Title;
	}
	
	public int get_AM_Number() {
		return AM_Number;
	}
	
	public	Date get_DOB(){
		return DOB;
	}
	
	public String[] get_Skills() {
		return Skills;
	}
	
	public String[] get_Languages() {
		return Languages;
	}
	
	public String get_Education() {
		return Education;
	}
	
	public	Assignment[] get_Assignments(){
		return Assignments;
	}
//---------------------------------------------------------------------------------------------------------		


//View My Profile						
//---------------------------------------------------------------------------------------------------------
	public void View_My_Profile() {
		System.out.println("Surname: "+ Surname+" \n");
		System.out.println("AM Number: "+ AM_Number+" \n");
		System.out.println("Date of Birth: "+ DOB+" \n");
		System.out.println("Title: "+ Student_Title+" \n");
		System.out.println("Current Education: "+ Education+" \n");
		for(int i=0;i<Skills_Counter;i++) {
			System.out.println("Skill: "+ Skills[i]+" \n");
		}
		for(int j=0;j<Skills_Counter;j++) {
			System.out.println("Language: "+ Languages[j]+" \n");
		}
		System.out.println("Number of Lessons: "+ Lessons.size()+" \n");
		System.out.println("Number of Friends: "+ Friends.size()+" \n");
	}
//--------------------------------------------------------------------------------------------------------
						
						
//Edit Profile						
//-------------------------------------------------------------------------------------------------------						
	public void Edit_Profile(Student Current_User) {
		Boolean loop=false;
		Boolean break_big_loop=false;
		Scanner scan = new Scanner(System.in);
		while(break_big_loop==false){
		System.out.println("Press 1 to change your Skills\n"+
						   "Press 2 to change your Languages\n"+
						   "Press 3 to change your Education\n"+
						   "Press 4 to Exit\n");
		int option= scan.nextInt();
		if(option==1){
			System.out.println("Current Skills:  \n");
			for(int i=0;i<Skills_Counter;i++) {
				System.out.println("Skill: "+ Skills[i]+" \n");
			}
			while(loop==false) {
				System.out.println("Press 1 to change your current Skills\n"+
						   "Press 2 to enter a new skill\n");
				int choice1= scan.nextInt();
				if(choice1==1) {
					Boolean loop1=false;
					int count_skill=0;
					while(loop1==false) {
						System.out.println("Please enter the skill you want to change: \n");
						String old_skill=scan.nextLine();
						for(int w=0;w<Skills_Counter;w++) {
							if(Skills[w].equals(old_skill)) {
								System.out.println("New Skill: \n");
								String skill= scan.nextLine();
								Skills[w]=skill;
								count_skill=1;
								loop1=true;
							}
						}
						if(count_skill==0) {
							System.out.println("Not a current skill that you have.Please retry. \n");
						}
					}
					loop=true;
				}else if(choice1==2) {
					System.out.println("New Skill: \n");
					String skill= scan.nextLine();
					Boolean check=false;
					for(int j=0;j<University.Global_Skils_Counter;j++) {
						if(University.Global_Skils[j].equals(skill)) {
							check=true;
						}
					}
					if(check==true) {
						Skills[Skills_Counter]=skill;
						Skills_Counter=Skills_Counter+1;
						loop=true;
					}else {
						this.BelongToDepartment.secretariat.Pending_Skills[this.BelongToDepartment.secretariat.Pending_Skills_Counter]=skill;
						this.BelongToDepartment.secretariat.Pending_Skills_Counter=this.BelongToDepartment.secretariat.Pending_Skills_Counter+1;
						loop=true;
						System.out.println("Skill Suggested. \n");
					}
					
				}else {
					System.out.println("Not an available option.Please retry. \n");
				}
			}
			System.out.println("Changes made. \n");
		}else if(option==2){
			System.out.println("Current Languages:  \n");
			for(int i=0;i<Languages_Counter;i++) {
				System.out.println("Language: "+ Languages[i]+" \n");
			}
			while(loop==false) {
				System.out.println("Press 1 to change your current Languages\n"+
						   "Press 2 to enter a new Language\n");
				int choice2= scan.nextInt();
				if(choice2==1) {
					Boolean loop1=false;
					int count_lang=0;
					while(loop1==false) {
						System.out.println("Please enter the language you want to change: \n");
						String old_lang=scan.nextLine();
						for(int w=0;w<Languages_Counter;w++) {
							if(Languages[w].equals(old_lang)) {
								System.out.println("New Language: \n");
								String lang= scan.nextLine();
								Languages[w]=lang;
								count_lang=1;
								loop1=true;
							}
						}
						if(count_lang==0) {
							System.out.println("Not a current Language that you have.Please retry. \n");
						}
					}
					loop=true;
				}else if(choice2==2) {
					System.out.println("New Language: \n");
					String lang= scan.nextLine();
					Languages[Languages_Counter]=lang;
					Languages_Counter=Languages_Counter+1;
					loop=true;
				}else {
					System.out.println("Not an available option.Please retry. \n");
				}
			}
			System.out.println("Changes made. \n");
		}else if(option==3){
			System.out.println("Current Education: "+ Education+" \n");
			System.out.println("New Education: \n");
			String education= scan.nextLine();
			Current_User.Education=education;
			System.out.println("Changes made. \n");
		}else if(option==4){
			break_big_loop=true;
			System.out.println("Exit.");
			//scan.close();
			return;
		}else{
			System.out.println("Not an available option.Please retry. \n");
		}
		}
		
		//scan.close();
		return;
	}
//--------------------------------------------------------------------------------------------------------						
						
						
//Friend Request						
//--------------------------------------------------------------------------------------------------------						
	public void Friend_Request(Student Other) {
		Other.Friends_Request[Other.Friends_Request_Counter]=this;
		Other.Friends_Request_Counter=Other.Friends_Request_Counter+1;
		Other.Pending_Requests[Other.Pending_Requests_Counter]=false;
		Other.Pending_Requests_Counter=Other.Pending_Requests_Counter+1;
	}
//---------------------------------------------------------------------------------------------------------						



//Enroll
//--------------------------------------------------------------------------------------------------------
	public void Enroll(Lesson lesson) {
		this.Lessons.add(lesson);
		lesson.Students.add(this);
	}
//-------------------------------------------------------------------------------------------------------


//Disenroll
//--------------------------------------------------------------------------------------------------------
	public void Disenroll(Lesson lesson) {
		for(int i=0;i<this.Lessons.size();i++) {
			if(this.Lessons.get(i)==lesson) {
				this.Lessons.remove(i);                //WARNING IT MIGHT NOT WORK  (Maybe a list works better)
				break;
			}
		}
		for(int j=0;j<lesson.Students.size();j++) {
			if(lesson.Students.get(j)==this) {
				lesson.Students.remove(j);        //WARNING IT MIGHT NOT WORK
				break;
			}
		}
	}
//-------------------------------------------------------------------------------------------------------


//Edit Friend Request						
//--------------------------------------------------------------------------------------------------------						
	public void Edit_Friend_Request() {
		Scanner scan = new Scanner(System.in);
		System.out.println("User "+Friends_Request[Friends_Request_Counter-1].get_Name()  +" sent you a friend request.\n");
		Boolean break_loop=false;
		while(break_loop==false){
		System.out.println("Please press 1 to Accept or 2  to Reject. \n");
		int reminder_option= scan.nextInt();
		if (reminder_option==1){
			Pending_Requests[Pending_Requests_Counter-1]=true;
			break_loop=true;
			Friends.add(Friends_Request[Friends_Request_Counter-1]);
			Friends_Request[Friends_Request_Counter-1].Friends.add(this);
		}else if (reminder_option==2){
			Pending_Requests[Pending_Requests_Counter-1]=false;
			break_loop=true;
		}
		else{
			System.out.println("Not an available option.Please retry. \n");
		}
		}
		//scan.close();
		
	}
//---------------------------------------------------------------------------------------------------------	


//Remove Friend					
//--------------------------------------------------------------------------------------------------------						
	public void Remove_Friend(Student Other) {
		for(int i=0;i<this.Friends.size();i++) {
			if(this.Friends.get(i)==Other) {
				this.Friends.remove(i);                       //WARNING IT MIGHT NOT WORK  (Maybe a list works better)
				break;
			}
		}
		for(int j=0;j<Other.Friends.size();j++) {
			if(Other.Friends.get(j)==this) { 
				Other.Friends.remove(j);                //WARNING IT MIGHT NOT WORK  (Maybe a list works better)
				break;
			}
		}
	}
//---------------------------------------------------------------------------------------------------------		


//Suggest Skill
//---------------------------------------------------------------------------------------------------------
	public void Suggest_Skill(String Skill) {
		
		Secretariat secretariat=this.BelongToDepartment.get_Secretariat();
		secretariat.Pending_Skills[secretariat.Pending_Skills_Counter]=Skill;
		secretariat.Pending_Skills_Counter=secretariat.Pending_Skills_Counter+1;
	}
//---------------------------------------------------------------------------------------------------------


//View lessons
//---------------------------------------------------------------------------------------------------------
	public void View_Lessons() {
		System.out.println("Your current Lessons: \n");
		for(int i=0;i<this.Lessons.size();i++) {
			System.out.println(this.Lessons.get(i).Name +"\n");
		}
	}
//---------------------------------------------------------------------------------------------------------


//View Lesson Grades
//---------------------------------------------------------------------------------------------------------
	public void View_Lesson_Grades(Lesson lesson) {
		System.out.println("Your assignment grades for the lesson "+lesson.Name+ ": \n");
		for(int i=0;i<lesson.Assignment_Counter;i++) {
			for(int j=0;j<lesson.Assignments[i].Grades_Counter;j++) {
				if(lesson.Assignments[i].Grades[j].student==this) {
					System.out.println("For assignment: "+lesson.Assignments[i].Name+ "\n");
					System.out.println(lesson.Assignments[i].Grades[j].grade + "\n");
				}
			}
			
		}
		
		System.out.println("Your total grade for the lesson "+lesson.Name+ ": \n");
		for(int w=0;w<lesson.Grades_Counter;w++) {
			if(lesson.Grades[w].student==this) {
				System.out.println(lesson.Grades[w].grade + "\n");
				break;
			}
		}
	}
//---------------------------------------------------------------------------------------------------------


//View Assignments
//---------------------------------------------------------------------------------------------------------
	public void View_Assignments(Lesson lesson) {
		for(int i=0;i<lesson.Assignment_Counter;i++) {
			System.out.println(lesson.Assignments[i].Name + "\n");
		}
	}
//---------------------------------------------------------------------------------------------------------


//Submit Assignment
//---------------------------------------------------------------------------------------------------------
	public void Submit_Assignment(Lesson lesson,Assignment assignment, File file) {
		for(int i=0;i<this.Lessons.size();i++) {
			if(this.Lessons.get(i)==lesson) {
				for(int j=0;j<lesson.Assignment_Counter;j++) {
					if(lesson.Assignments[j]==assignment) {
						assignment.Submissions[assignment.Submissions_Counter].file=file;
						assignment.Submissions[assignment.Submissions_Counter].student=this;
						assignment.Submissions_Counter=assignment.Submissions_Counter+1;
						break;
					}
				}
				
			}
		}
	}
//---------------------------------------------------------------------------------------------------------


//View Submission
//---------------------------------------------------------------------------------------------------------
	public File View_Submission(Lesson lesson,Assignment assignment) {
		for(int i=0;i<this.Lessons.size();i++) {
			if(this.Lessons.get(i)==lesson) {
				for(int j=0;j<lesson.Assignment_Counter;j++) {
					if(lesson.Assignments[j]==assignment) {
						for(int w=0;w<assignment.Submissions_Counter;w++) {
							if(assignment.Submissions[w].student==this) {
								return assignment.Submissions[w].get_File();
							}
						}
						
					}
				}
				
			}
		}
		return null;
	}
//---------------------------------------------------------------------------------------------------------



//Edit Submission
//---------------------------------------------------------------------------------------------------------
	public void Edit_Submission(Lesson lesson,Assignment assignment,File file) {
		for(int i=0;i<this.Lessons.size();i++) {
			if(this.Lessons.get(i)==lesson) {
				for(int j=0;j<lesson.Assignment_Counter;j++) {
					if(lesson.Assignments[j]==assignment) {
						for(int w=0;w<assignment.Submissions_Counter;w++) {
							if(assignment.Submissions[w].student==this) {
								assignment.Submissions[w].file=file;
							}
						}
						
					}
				}
				
			}
		}
	}
//---------------------------------------------------------------------------------------------------------
//Follow??? Unfollow??

}
