package Model;

import java.time.LocalDate;


public class Assignment {

	public int Assignment_ID;
	private static int Assignment_ID_Counter=0;
	public String Name;
	public LocalDate Date_Starting;
	public LocalDate Date_Ending;
	public String Description;
	public Boolean Status;
	public Lesson lesson;
	public Grade[] Grades;
	public int Grades_Counter;
	public Submission[] Submissions;
	public int Submissions_Counter;
	
//Constructor
//-------------------------------------------------------------------------------------
	public Assignment(String Name,String Description,LocalDate Date_Starting,LocalDate Date_Ending,Boolean Status,Lesson lesson){
		this.Assignment_ID=Assignment_ID_Counter + 1;
		this.Name=Name;
		this.Date_Ending=Date_Ending;
		this.Date_Starting=Date_Starting;
		this.Description=Description;
		this.Status=Status;
		this.lesson=lesson;
	}
//---------------------------------------------------------------------------------------


//set methods
//------------------------------------------------------------------------------------------------------
	public void set_Name(String Name){	
		this.Name=Name;
	}
	
	public void set_Description(String Description){	
		this.Description=Description;
	}
	
	public void set_Date_Starting(LocalDate Date_Starting){	
		this.Date_Starting=Date_Starting;
	}
	
	public void set_Date_Ending(LocalDate Date_Ending){	
		this.Date_Ending=Date_Ending;
	}
	
	public void set_Status(Boolean Status){	
		this.Status=Status;
	}
	
	public void set_Lesson(Lesson lesson){	
		this.lesson=lesson;
	}
	
	public void set_Grades(Grade grade){	
		this.Grades[this.Grades_Counter]=grade;
		this.Grades_Counter=this.Grades_Counter+1;
	}
//---------------------------------------------------------------------------------------------------------


//get methods
//---------------------------------------------------------------------------------------------------------
	public	String get_Name(){
		return Name;
	}
	
	public	String get_Description(){
		return Description;
	}
	
	public	LocalDate get_Date_Ending(){
		return Date_Ending;
	}
	
	public	LocalDate get_Date_Starting(){
		return Date_Starting;
	}
	
	public	Boolean get_Status(){
		return Status;
	}
	
	public	Lesson get_Lesson(){
		return lesson;
	}
	
	public Grade[] get_Grades(){
		return Grades;
	}
//---------------------------------------------------------------------------------------------------------	
	
//Update Status Assignment
//--------------------------------------------------------------------------------------------------------
	public void Update_Status_Assignment() {
		LocalDate localDate = LocalDate.now();
//		if(this.Date_Ending>localDate)                     //FIX!!!!!!!!!!!!
		{
			this.Status=false;
		}
	}
//--------------------------------------------------------------------------------------------------------
					
					
	
}
