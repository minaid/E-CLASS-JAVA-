package Model;

import java.util.List;
import java.util.Scanner;
import java.util.TimeZone;

public class Secretariat extends User {

	public String Office_Hours;
	public String Office;
	public String[] Pending_Skills;
	public int Pending_Skills_Counter=0;
	
//Constructor
//-----------------------------------------------------------------------------------------------------------------------------
	public Secretariat(String Username, String Password, String Email, String Name,
			Boolean Notification_enabled, Boolean Is_Locked, Boolean Is_Active, Department BelongToDepartment,
			TimeZone GMT, Boolean Is_Online) {
		super(Username, Password, Email, Name, Notification_enabled, Is_Locked, Is_Active, BelongToDepartment, GMT, Is_Online);
		// TODO Auto-generated constructor stub
		this.Pending_Skills=new String[1000];
	}
//------------------------------------------------------------------------------------------------------------------------------
	

//Abstract Method
//------------------------------------------------------------------
	@Override
	void Temp() {
		// TODO Auto-generated method stub
	}
//------------------------------------------------------------------
	
	
//set methods
//------------------------------------------------------------------------------------------------------
	public void set_Office_Hours(String Office_Hours){	
		this.Office_Hours=Office_Hours;
	}
	
	public void set_Office(String Office){	
		this.Office=Office;
	}
	
	public void set_Pending_Skills(String Skill){	
		this.Pending_Skills[this.Pending_Skills_Counter]=Skill;
		this.Pending_Skills_Counter=this.Pending_Skills_Counter+1;
	}
//---------------------------------------------------------------------------------------------------------		
	
	
//get methods
//---------------------------------------------------------------------------------------------------------		
	public String get_Office_Hours() {
		return Office_Hours;
	}
	
	public String get_Office() {
		return Office;
	}
	
	public	String[] get_Pending_Skills(){
		return Pending_Skills;
	}
//---------------------------------------------------------------------------------------------------------		
	
	
//View My Profile						
//---------------------------------------------------------------------------------------------------------
	public void View_My_Profile() {
		System.out.println("Office: "+ Office+" \n");
		System.out.println("Office Hours: "+ Office_Hours+" \n");
	}
//--------------------------------------------------------------------------------------------------------	
	
	
//Edit Profile						
//-------------------------------------------------------------------------------------------------------						
	public void Edit_Profile_S(Secretariat Current_User) {
		Boolean break_big_loop=false;
		Scanner scan = new Scanner(System.in);
		while(break_big_loop==false){
			System.out.println(
						"Press 1 to change your Office\n"+
						"Press 2 to change your Office Hours\n"+
						"Press 3 to Exit\n");
			int option= scan.nextInt();
			if(option==1){
				System.out.println("Current Office: "+ Office+" \n");
				System.out.println("New Office: \n");
				String office= scan.nextLine();
				Current_User.Office=office;
			}else if(option==2){
				System.out.println("Current Office Hours: "+ Office_Hours+" \n");
				System.out.println("New Office Hours: \n");
				String hours= scan.nextLine();
				Current_User.Office_Hours=hours;
			}else if(option==3){
				break_big_loop=true;
				System.out.println("Exit.");
				//scan.close();
				return;
			}else{
				System.out.println("Not an available option.Please retry. \n");
			}
			}
		//scan.close();
		return;
	}
//--------------------------------------------------------------------------------------------------------					
							

//Create Announcement
//---------------------------------------------------------------------------------------------------------
	public void Create_Announcement() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Please enter the Title for the Announcement: \n");
		String title= scan.nextLine();
		System.out.println("Please enter the Description for the Announcement: \n");
		String description= scan.nextLine();
		this.BelongToDepartment.set_Announcements(new Announcement(title,description));
		this.BelongToDepartment.Announcement_Counter=this.BelongToDepartment.Announcement_Counter+1;
		//scan.close();
		System.out.println("Announcement Created!\n");
	}
//---------------------------------------------------------------------------------------------------------
				
				
//Edit Announcement
//---------------------------------------------------------------------------------------------------------
	public void Edit_Announcement(Announcement announcement) {
		Scanner scan = new Scanner(System.in);
		Boolean break_big_loop=false;
		while(break_big_loop==false){
		System.out.println("Press 1 to change the Title\n"+
				   "Press 2 to change the Description\n"+
				   "Press 3 to Exit\n");
		int option= scan.nextInt();
		if(option==1){
			System.out.println("Please enter the Title for the Announcement: \n");
			String title= scan.nextLine();
			announcement.Title=title; 
		}else if(option==2) {
			System.out.println("Please enter the Description for the Announcement: \n");
			String description= scan.nextLine();
			announcement.Description=description;
		}else if(option==3) {
			break_big_loop=true;
			//scan.close();
			System.out.println("Announcement Edited!\n");
			return;
		}else {
			System.out.println("Not an available option.Please retry. \n");
		}
		}
		//scan.close();
		System.out.println("Announcement Edited!\n");				
	}
//---------------------------------------------------------------------------------------------------------
	
	
//Create User
//---------------------------------------------------------------------------------------------------------
		
			public void Create_User() {
				Boolean break_great_loop=false;
				Scanner scan = new Scanner(System.in);
				while(break_great_loop==false) {
					System.out.println("Press 1 to create a Student \n"+
							   "Press 2 to create a Teacher \n"+
							   "Press 3 to change to Exit\n");
					int option= scan.nextInt();
					if(option==1){
						break_great_loop=true;
						System.out.println("Please enter the Username: \n");
						String Username= scan.nextLine();
						Username= scan.nextLine();
						System.out.println("Please enter the Password: \n");
						String Password= scan.nextLine();
						//Password= scan.nextLine();
						System.out.println("Please enter the Email: \n");
						String Email= scan.nextLine();
						//Email= scan.nextLine();
						System.out.println("Please enter the Name: \n");
						String Name= scan.nextLine();
						//Name= scan.nextLine();
						System.out.println("Please enter the Surname: \n");
						String Surname= scan.nextLine();
						//Surname= scan.nextLine();
						this.BelongToDepartment.Add_Student(new Student(Username,Password,Email,Name,Surname,true,false,true,this.BelongToDepartment,TimeZone.getTimeZone("1"),false));
					}else if(option==2){
						break_great_loop=true;
						System.out.println("Please enter the Username: \n");
						String Username= scan.nextLine();
						Username= scan.nextLine();
						System.out.println("Please enter the Password: \n");
						String Password= scan.nextLine();
						//Password= scan.nextLine();
						System.out.println("Please enter the Email: \n");
						String Email= scan.nextLine();
						//Email= scan.nextLine();
						System.out.println("Please enter the Name: \n");
						String Name= scan.nextLine();
						//Name= scan.nextLine();
						System.out.println("Please enter the Surname: \n");
						String Surname= scan.nextLine();
						//Surname= scan.nextLine();
						this.BelongToDepartment.Add_Teacher(new Teacher(Username,Password,Email,Name,Surname,true,false,true,this.BelongToDepartment,TimeZone.getTimeZone("-2"),false));
					}
					else {
						System.out.println("Not an available option.Please retry. \n");
					}
			
			}
				System.out.println("User Created. \n");
				return;
			}
				
//---------------------------------------------------------------------------------------------------------
			
			
//Edit User
//---------------------------------------------------------------------------------------------------------
	public void Edit_User(User Current_User) {
		Boolean break_big_loop=false;
		Boolean status=false;                           //need to check the value initialized
		Scanner scan = new Scanner(System.in);
		while(break_big_loop==false){
		System.out.println("Press 1 to change the Name\n"+
						   "Press 2 to change the Password\n"+
						   "Press 3 to change the Email\n"+
						   "Press 4 to change the Account Locked\n"+
						   "Press 5 to change the Account Active\n"+
						   "Press 6 to change the Department\n"+
						   "Press 7 to change the Department\n"+
						   "Press 8 to Exit\n");
		int option= scan.nextInt();
		if(option==1){
			System.out.println("Current Name: "+ Current_User.get_Name()+" \n");
			System.out.println("New Name: \n");
			String name= scan.nextLine();
			Current_User.set_Name(name);
			System.out.println("Changes made. \n");
		}else if(option==2){
			System.out.println("Current Password: "+ Current_User.get_Password()+" \n");
			System.out.println("New Password: \n");
			String password= scan.nextLine();
			Current_User.set_Password(password);
			System.out.println("Changes made. \n");
		}else if(option==3){
			System.out.println("Current Email: "+ Current_User.get_Email()+" \n");
			System.out.println("New Email: \n");
			String email= scan.nextLine();
			Current_User.set_Email(email);
			System.out.println("Changes made. \n");
		}else if(option==4){
			if(Current_User.get_Is_Locked()==true) {
				System.out.println("Locked: Yes \n");
			}else {
				System.out.println("Locked: No \n");
			}
			Boolean break_loop2=false;
			while(break_loop2==false){
			System.out.println("Press 1 for Locked: Yes , 2 for Locked: No \n");
			System.out.println("Enter Choice: \n");
			int status_option= scan.nextInt();
			if (status_option==1){
				status=true;
				break_loop2=true;
			}else if (status_option==2){
				status=false;
				break_loop2=true;
			}
			else{
				System.out.println("Not an available option.Please retry. \n");
			}
			}
			Current_User.set_Is_Locked(status);
			System.out.println("Changes made. \n");
		}else if(option==5){
			if(Current_User.get_Is_Active()==true) {
				System.out.println("Active: Yes \n");
			}else {
				System.out.println("Active: No \n");
			}
			Boolean break_loop2=false;
			while(break_loop2==false){
			System.out.println("Press 1 for Active: Yes , 2 for Active: No \n");
			System.out.println("Enter Choice: \n");
			int status_option= scan.nextInt();
			if (status_option==1){
				status=true;
				break_loop2=true;
			}else if (status_option==2){
				status=false;
				break_loop2=true;
			}
			else{
				System.out.println("Not an available option.Please retry. \n");
			}
			}
			Current_User.set_Is_Active(status);
			System.out.println("Changes made. \n");
		}else if(option==6){
			System.out.println("Current Department: "+ Current_User.get_BelongToDepartment()+" \n");
			Boolean check=false;
			while(check==false) {
			System.out.println("New Department: \n");
			String dep= scan.nextLine();
			for(int j=0;j<University.Department_counter;j++) {
				if(dep.equals(University.Departments[j].Name)) {
					Current_User.set_BelongToDepartment(University.Departments[j]);
					check=true;
				}
			}
			if(check==false) {
				System.out.println("Not an available Department.Please retry. \n");
			}
			}
			System.out.println("Changes made. \n");
		}else if(option==7){
			if(Current_User instanceof Student) {
				System.out.println("Current Surname: "+ ((Student)Current_User).Surname+" \n");
				System.out.println("New Surname: \n");
				String name= scan.nextLine();
				((Student)Current_User).set_Surname(name);
				System.out.println("Changes made. \n");
			}else if(Current_User instanceof Teacher) {
				System.out.println("Current Surname: "+ ((Teacher)Current_User).Surname+" \n");
				System.out.println("New Surname: \n");
				String name= scan.nextLine();
				((Teacher)Current_User).set_Surname(name);
				System.out.println("Changes made. \n");
			}
		}else if(option==8){
			break_big_loop=true;
			System.out.println("Exit.");
			//scan.close();
			return;
		}else{
			System.out.println("Not an available option.Please retry. \n");
		}
		}
		//scan.close();
		return;
	}
			
//---------------------------------------------------------------------------------------------------------		
			
	
//Edit Lesson
//--------------------------------------------------------------------------------------------------------
	public void Edit_Lesson(Lesson lesson) {
		Scanner scan = new Scanner(System.in);
		Boolean break_big_loop=false;
		while(break_big_loop==false){
		System.out.println("Press 1 to change the Name\n"+
				   "Press 2 to change the Description\n"+
				   "Press 3 to change the Teacher\n"+
				   "Press 4 to change the Department\n"+
				   "Press 5 to Exit\n");
		int option= scan.nextInt();
		if(option==1){
			System.out.println("Please enter the Name of the Lesson: \n");
			String Name= scan.nextLine();
			lesson.Name=Name;
		}else if(option==2) {
			System.out.println("Please enter the Description of the Lesson: \n");
			String description= scan.nextLine();
			lesson.Description=description;
		}else if(option==3) {
			Boolean check=false;
			while(check==false) {
				System.out.println("Please enter the Name of the Teacher: \n");
				String teacher_name= scan.nextLine();
				System.out.println("Please enter the Surname of the Teacher: \n");
				String teacher_surname= scan.nextLine();
				List<Teacher> teachers=lesson.BelongToDepartment.get_Teachers();
				for(int i=0;i<teachers.size();i++) {
					Teacher teacher=teachers.get(i);
					if(teacher.get_Name().equals(teacher_name) && teacher.get_Surname().equals(teacher_surname) ) {
						 lesson.teacher=teacher;
						 check=true;
					}
				}
				if(check==false) {
					System.out.println("Not an available Teacher.Please retry. \n");
				}
			}
		}else if(option==4) {
			Boolean check=false;
			while(check==false) {
				System.out.println("Please enter the Name of the Department: \n");
				String name= scan.nextLine();
				for(int i=0;i<University.Department_counter;i++) {
					if(University.Departments[i].Name.equals(name)) {
						 lesson.BelongToDepartment=University.Departments[i];
						 check=true;
					}
				}
				if(check==false) {
					System.out.println("Not an available Department.Please retry. \n");
				}
			}
		}else if(option==5) {
			break_big_loop=true;
			//scan.close();
			System.out.println("Lesson Edited!\n");
			return;
		}else {
			System.out.println("Not an available option.Please retry. \n");
		}
		}
		//scan.close();
		System.out.println("Lesson Edited!\n");
	}
//--------------------------------------------------------------------------------------------------------
			
			

//Create Lesson
//--------------------------------------------------------------------------------------------------------
	public void Create_Lesson() {
		Scanner scan = new Scanner(System.in);
		Teacher teacher=null;
		System.out.println("Please enter the Name for the Lesson: \n");
		String Name= scan.nextLine();
		Name= scan.nextLine();
		System.out.println("Please enter the Description for the Lesson: \n");
		String description= scan.nextLine();
		description= scan.nextLine();
		System.out.println("Please enter the Name of the Teacher: \n");
		String teacher_name= scan.nextLine();
		teacher_name= scan.nextLine();
		System.out.println("Please enter the Surname of the Teacher: \n");
		String teacher_surname= scan.nextLine();
		teacher_surname= scan.nextLine();
		List<Teacher> teachers=this.BelongToDepartment.get_Teachers();
		for(int i=0;i<teachers.size();i++) {
			Teacher temp=teachers.get(i);
			if(temp.get_Name().equals(teacher_name) && temp.Surname.equals(teacher_surname)) {
				 teacher=temp;
			}
			
		}
		this.BelongToDepartment.Add_Lesson(new Lesson(teacher,Name,this.BelongToDepartment,description));
		//scan.close();
		System.out.println("Lesson Created!\n");
	}
//--------------------------------------------------------------------------------------------------------
		
			
//View Departments
//--------------------------------------------------------------------------------------------------------
	public void View_Departments() {
		System.out.println("Departments: \n");
		for(int i=0;i<University.Department_counter;i++) {
			System.out.println(University.Departments[i].Name+"\n");
		}
	}
//--------------------------------------------------------------------------------------------------------
			
			
//Confirm Skill
//-------------------------------------------------------------------------------------------------------
	public void Confirm_Skill() {
		University.Global_Skils[University.Global_Skils_Counter]=this.Pending_Skills[this.Pending_Skills_Counter];
		University.Global_Skils_Counter=University.Global_Skils_Counter+1;
	}
//-------------------------------------------------------------------------------------------------------
			
			
//Reject Skill
//-------------------------------------------------------------------------------------------------------
	public void Reject_Skill() {                     //Do we need it???
		
	}			
//-------------------------------------------------------------------------------------------------------		
			
			
//View Department Lessons
//-------------------------------------------------------------------------------------------------------
	public void View_Department_Lessons(Department department) {
		System.out.println("Lessons: \n");
		for(int i=0;i<department.get_Lessons().size();i++) {
			System.out.println(department.get_Lessons().get(i).Name+"\n");
		}
	}			
//-------------------------------------------------------------------------------------------------------			
			
}
