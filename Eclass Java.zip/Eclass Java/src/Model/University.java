package Model;

import java.util.List;
import java.util.Scanner;

public class University {
	public static  Department[] Departments;
	static int Department_counter=0;  //not sure
	public static Message[] Messages;
	public static int Messages_Counter=0;
	public static String[] Global_Skils;
	public static int Global_Skils_Counter=0;


//Constructor
//----------------------------------------------------------------------------
	public University (){									//Department[] Departments, Message[] Messages
			University.Departments=new Department[1000];    //check value!!!
			University.Messages=new Message[1000];
			University.Global_Skils=new String[1000];
		}
//----------------------------------------------------------------------------


//set methods
//------------------------------------------------------------------------------------------------------
	public void set_Departments(Department department){	
		University.Departments[Department_counter]=department;
		Department_counter=Department_counter+1;
	}
	
	public void set_Messages(Message message){	
		University.Messages[Messages_Counter]=message;
		Messages_Counter=Messages_Counter+1;
	}
	
	public void set_Global_Skils(String Skill){	
		University.Global_Skils[Global_Skils_Counter]=Skill;
		Global_Skils_Counter=Global_Skils_Counter+1;
	}
//---------------------------------------------------------------------------------------------------------


//get methods
//---------------------------------------------------------------------------------------------------------
	public Department[] get_Departments(){
		return Departments;
	}
	
	public Message[] get_Messages(){
		return Messages;
	}
	
	public Department get_Department_Byname(String name) {
		for(int i=0;i<Department_counter;i++) {
			if(name.equals(Departments[i].Name)) {
				return Departments[i];
			}
		}
		return null;
	}
	
	public String[] get_Global_Skils(){
		return Global_Skils;
	}
//---------------------------------------------------------------------------------------------------------

	
//Create Department
//--------------------------------------------------------------------------------------------------------
	public void Create_Department(String name){
		Departments[Department_counter]=new Department(name);
		Department_counter=Department_counter+1;
	}
//--------------------------------------------------------------------------------------------------------


//Find Current User
//--------------------------------------------------------------------------------------------------------
	public static User find_Current_User(String Username) {
		for(int i=0;i< Department_counter;i++) {
			List<User> users=Departments[i].get_Users();
			for(int j=0;j<users.size();j++) {
				if(Username.equals(users.get(j).get_Username())) {
					return users.get(j);
				}
			}
		}
		return null;	
	}
//--------------------------------------------------------------------------------------------------------

//Find Another User
//--------------------------------------------------------------------------------------------------------
	public static User find_Another_User(String Email) {
		
		for(int i=0;i< Department_counter;i++) {
			List<User> users=Departments[i].get_Users();
			for(int j=0;j<users.size();j++) {
				if(Email.equals(users.get(j).get_Email())) {
					return users.get(j);
				}
			}
		}
		
		System.out.println("No such User exists.\n");
		return null;
		
	}
//--------------------------------------------------------------------------------------------------------




//Home
//---------------------------------------------------------------------
	public static void Home(User user){
		//normally starts session
		System.out.println("Welcome "+ user.get_Name()+ "\n");
		Boolean break_big_loop=false;
		Boolean loop=false;                          
		Scanner scan = new Scanner(System.in);
		if(user instanceof Student) {
			while(break_big_loop==false){
			loop=false;
			System.out.println("Press 1 to View your Profile\n"+
							   "Press 2 to Search Lessons or Users\n"+
							   "Press 3 to Create an Event\n"+
							   "Press 4 to View your Events\n"+
							   "Press 5 to Edit an Event\n"+
							   "Press 6 to View Users Online\n"+
							   "Press 7 to View Notifications\n"+
							   "Press 8 to View Event Invitations\n"+
							   "Press 9 to Send a Message to a User\n"+
							   "Press 10 to View Message History\n"+
							   "Press 11 to View your Department's Announcements\n"+
							   "Press 12 to View a Lesson's Announcements\n"+
							   "Press 13 to View your Department's Lessons\n"+
							   "Press 14 to View your Lessons\n"+
							   "Press 15 to View your Friends\n"+
							   "Press 16 to View your Current Assignments\n"+
							   "Press 17 to Logout\n"+
							   "Please enter your choice:\n");
			int option= scan.nextInt();
			if(option==1){
				user.View_My_Profile();
				((Student) user).View_My_Profile();
				while(loop=false) {
					System.out.println("Press 1 to Edit your Profile\n"+
							   "Press 2 to go to Main Menu\n");
					int choice= scan.nextInt();
					if(choice==1) {
						user.Edit_Profile(user);
						((Student) user).Edit_Profile(user);
						loop=true;
					}else if(choice==2) {
						loop=true;
					}else {
						System.out.println("Not an available option.Please retry. \n");
					}
				}
			}else if(option==2){
				System.out.println("Please enter a keyword (Name) to search a User or Lesson: \n");
				String Keyword=scan.nextLine();
				Keyword=scan.nextLine();
				user.Search(Keyword);
				Boolean loop3=false;
				while(loop3==false) {
					System.out.println("If you want to View the profile of a User press 1 or else press 2 to Main Menu. \n");
					int choice= scan.nextInt();
					if(choice==1) {
						Boolean search=false;
						while(search==false) {
						System.out.println("Please enter the email of the User: \n");
						Keyword=scan.nextLine();
						Keyword=scan.nextLine();
						User tmp=University.find_Another_User(Keyword);
						if(tmp!=null) {
							loop3=true;
							user.View_User_Profile(tmp);
							search=true;
						}else {
							System.out.println("Please retry. \n");
						}
						}
					}else if(choice==2) {
						loop3=true;
					}else {
						System.out.println("Not an available option.Please retry. \n");
					}
				}
				while(loop==false) {
					System.out.println("If you want to Search again press 1 or press 2 to Main Menu. \n");
					int choice= scan.nextInt();
					if(choice==1) {
						System.out.println("Please enter a keyword to search a User or Lesson: \n");
						Keyword=scan.nextLine();
						Keyword=scan.nextLine();
						user.Search(Keyword);
						loop=true;
					}else if(choice==2) {
						loop=true;
					}else {
						System.out.println("Not an available option.Please retry. \n");
					}
				}
			}else if(option==3){
				user.Create_Event(user);
			}else if(option==4){
				user.View_Events(user);
			}else if(option==5){
				user.View_Events(user);
				while(loop==false) {
					System.out.println("Please enter an event to edit: \n");
					String event=scan.nextLine();
					for(int i=0;i<user.User_Events.size();i++) {
						if(user.User_Events.get(i).Name.equals(event)) {
							user.Edit_Event(user, user.User_Events.get(i));
							loop=true;
						}
					}
					if(loop==false) {
						System.out.println("You entered wrong Event name.Please retry. \n");
					}
				}
			}else if(option==6){
				user.View_Users_Online();
			}else if(option==7){
				user.View_Notifications(user);
			}else if(option==8){
				System.out.println("Invitations: \n");
				for(int i=0;i<user.User_Events.size();i++) {
					for(int j=0;j<user.User_Events.get(i).Users_Invited_Counter;j++) {
						if(user.User_Events.get(i).Users_Invited()[j]==user) {
							System.out.println(user.User_Events.get(i).Name+"\n");
						}
					}
				}
				while(loop==false) {
					System.out.println("Press 1 to Edit your Event Invitation\n"+
							   "Press 2 to go to Main Menu\n");
					int choice= scan.nextInt();
					if(choice==1) {
						System.out.println("All Events: \n");
						user.View_Events(user);
						Boolean loop2=false;
						while(loop2==false) {
							System.out.println("Please enter the event name: \n");
							String event=scan.nextLine();
							for(int i=0;i<user.User_Events.size();i++) {
								if(user.User_Events.get(i).Name.equals(event)) {
									user.Edit_EventInvitation(user, user.User_Events.get(i));
									loop2=true;
								}
							}
							if(loop2==false) {
								System.out.println("Not an available event.Please retry. \n");
							}
						}
						loop=true;
					}else if(choice==2) {
						loop=true;
					}else {
						System.out.println("Not an available option.Please retry. \n");
					}
				}
			}else if(option==9){
				Boolean loop9=false;
				while(loop9==false) {
					System.out.println("Please enter the Name of the user to send Message to: \n");
					String name=scan.nextLine();
					name=scan.nextLine();
					for(int i=0;i<user.BelongToDepartment.get_Users().size();i++) {
						if(user.BelongToDepartment.get_Users().get(i).get_Name().equals(name)) {
							user.Send_Message(user, user.BelongToDepartment.get_Users().get(i));
							loop9=true;
						}
					}
					if(loop9==false) {
						System.out.println("You entered wrong Name.Please retry. \n");
					}
				}
			}else if(option==10){
				while(loop==false) {
					System.out.println("Please enter the Name of the user to view message history: \n");
					String name=scan.nextLine();
					name=scan.nextLine();
					for(int i=0;i<user.BelongToDepartment.get_Users().size();i++) {
						if(user.BelongToDepartment.get_Users().get(i).get_Name().equals(name)) {
							user.View_Message_History(user, user.BelongToDepartment.get_Users().get(i));
							loop=true;
						}
					}
					if(loop==false) {
						System.out.println("You entered wrong Name or there is no Message History with this User.Please retry. \n");
					}
				}
			}else if(option==11){
				user.View_Department_Announcements(user);
			}else if(option==12){
				((Student) user).View_Lessons(); 
				while(loop==false) {
					System.out.println("Please enter the Name of the Lesson: \n");
					String name=scan.nextLine();
					name=scan.nextLine();
					for(int i=0;i<((Student)user).Lessons.size();i++) {
						if(((Student)user).Lessons.get(i).Name.equals(name)) {
							((Student)user).View_Lesson_Announcements(user, ((Student)user).Lessons.get(i));
							loop=true;
						}
					}
					if(loop==false) {
						System.out.println("You have not enrolled in this lesson.Please retry. \n");
					}
				}
			}else if(option==13){
				System.out.println("Your Department's Lessons: \n");
				for(int i=0;i<user.BelongToDepartment.get_Lessons().size();i++) {
					System.out.println(user.BelongToDepartment.get_Lessons().get(i).Name+"\n");
				}
			}else if(option==14){
				((Student) user).View_Lessons();
				while(loop==false) {
					System.out.println("Press 1 to View your Submissions in a Lesson\n"+
							   "Press 2 to go to Main Menu\n");
					int choice= scan.nextInt();
					if(choice==1) {
						Boolean check1=false;
						while(check1==false) {
							System.out.println("Please enter a Lesson: \n");
							String lesson=scan.nextLine();
							lesson=scan.nextLine();
							for(int w=0;w<((Student) user).Lessons.size();w++) {
								if(lesson.equals(((Student) user).Lessons.get(w).Name)) {
									check1=true;
									((Student) user).View_Lesson_Grades(((Student) user).Lessons.get(w));
									((Student) user).View_Assignments(((Student) user).Lessons.get(w));
									Boolean check2=false;
									while(check2==false) {
										System.out.println("Please enter an Assignment: \n");
										String assignment=scan.nextLine();
										for(int l=0;l<((Student) user).Assignments_Counter;l++) {
											if(assignment.equals(((Student) user).Assignments[l].Name)) {
												check2=true;
												((Student) user).View_Submission(((Student) user).Lessons.get(w), ((Student) user).Assignments[l]);
												System.out.println("Press 1 to Edit the Submission\n"+
															"Press 2 to Submit an Assignment\n"+
														   "Press 3 to go to Main Menu\n");
												int choice3= scan.nextInt();
												if(choice3==1) {
													//((Student) user).Edit_Submission(((Student) user).Lessons[w], ((Student) user).Assignments[l], file);
													loop=true;
												}else if(choice3==2) {
													//((Student) user).Submit_Assignment(((Student) user).Lessons[w], ((Student) user).Assignments[l], file);
													loop=true;
												}else if(choice3==3) {
													loop=true;
												}else {
													System.out.println("Not an available option.Please retry. \n");
												}
												
											}
										}
										if(check2==false) {
											System.out.println("Not an Assignment available.Please retry. \n");
										}
										
									}
								}
							}
							if(check1==false) {
								System.out.println("Not a lesson available.Please retry. \n");
							}
							
						}
						loop=true;
					}else if(choice==2) {
						loop=true;
					}else {
						System.out.println("Not an available option.Please retry. \n");
					}
				}
			}else if(option==15){
				System.out.println("Your Friends: \n");
				for(int i=0;i<((Student) user).Friends.size();i++) {
					System.out.println(((Student) user).Friends.get(i).get_Name()+" "+((Student) user).Friends.get(i).Surname +"\n");
				}
			}else if(option==16){
				System.out.println("Your Current Assignments are: \n");
				for(int i=0;i<((Student) user).Assignments_Counter;i++) {
					if(((Student) user).Assignments[i].Status==true) {
					System.out.println(((Student) user).Assignments[i].Name+"\n");
					}
				}
			}else if(option==17){
				break_big_loop=true;
				user.LogOut(user);
				scan.close();
			}else{
				System.out.println("Not an available option.Please retry. \n");
			}
			}
		}else if(user instanceof Teacher) {                                 //TEACHER
			while(break_big_loop==false){
				loop=false;
				System.out.println("Press 1 to View your Profile\n"+
								   "Press 2 to Search Lessons or Users\n"+
								   "Press 3 to Create an Event\n"+
								   "Press 4 to View your Events\n"+
								   "Press 5 to Edit an Event\n"+
								   "Press 6 to View Users Online\n"+
								   "Press 7 to View Notifications\n"+
								   "Press 8 to View Event Invitations\n"+
								   "Press 9 to Send a Message to a User\n"+
								   "Press 10 to View Message History\n"+
								   "Press 11 to View your Department's Announcements\n"+
								   "Press 12 to View a Lesson's Announcements\n"+
								   "Press 13 to View your Department's Lessons\n"+
								   "Press 14 to View your Lessons\n"+
								   "Press 15 to Logout\n"+
								   "Please enter your choice:\n");
				int option= scan.nextInt();
				if(option==1){
					user.View_My_Profile();
					((Teacher) user).View_My_Profile();
					while(loop==false) {
						System.out.println("Press 1 to Edit your Profile\n"+
								   "Press 2 to go to Main Menu\n");
						int choice= scan.nextInt();
						if(choice==1) {
							user.Edit_Profile(user);
							((Teacher) user).Edit_Profile2((Teacher)user);
							loop=true;
						}else if(choice==2) {
							loop=true;
						}else {
							System.out.println("Not an available option.Please retry. \n");
						}
					}
				}else if(option==2){
					System.out.println("Please enter a keyword(Name) to search a User or Lesson: \n");
					String Keyword=scan.nextLine();
					Keyword=scan.nextLine();
					user.Search(Keyword);
					Boolean loop3=false;
					while(loop3==false) {
						System.out.println("If you want to View the profile of a User press 1 or else press 2 to Main Menu. \n");
						int choice= scan.nextInt();
						if(choice==1) {
							Boolean search=false;
							while(search==false) {
							System.out.println("Please enter the email of the User: \n");
							Keyword=scan.nextLine();
							Keyword=scan.nextLine();
							User tmp=University.find_Another_User(Keyword);
							if(tmp!=null) {
								loop3=true;
								user.View_User_Profile(tmp);
								search=true;
							}else {
								System.out.println("Please retry. \n");
							}
							}
						}else if(choice==2) {
							loop3=true;
						}else {
							System.out.println("Not an available option.Please retry. \n");
						}
					}
					while(loop==false) {
						System.out.println("If you want to Search again press 1 or press 2 to Main Menu. \n");
						int choice= scan.nextInt();
						if(choice==1) {
							System.out.println("Please enter a keyword to search a User or Lesson: \n");
							Keyword=scan.nextLine();
							Keyword=scan.nextLine();
							user.Search(Keyword);
							loop=true;
						}else if(choice==2) {
							loop=true;
						}else {
							System.out.println("Not an available option.Please retry. \n");
						}
					}
				}else if(option==3){
					user.Create_Event(user);
				}else if(option==4){
					user.View_Events(user);
				}else if(option==5){
					user.View_Events(user);
					while(loop==false) {
						System.out.println("Please enter an event to edit: \n");
						String event=scan.nextLine();
						for(int i=0;i<user.User_Events.size();i++) {
							if(user.User_Events.get(i).Name.equals(event)) {
								user.Edit_Event(user, user.User_Events.get(i));
								loop=true;
							}
						}
						if(loop==false) {
							System.out.println("You entered wrong Event name.Please retry. \n");
						}
					}
				}else if(option==6){
					user.View_Users_Online();
				}else if(option==7){
					user.View_Notifications(user);
				}else if(option==8){
					System.out.println("Invitations: \n");
					for(int i=0;i<user.User_Events.size();i++) {
						for(int j=0;j<user.User_Events.get(i).Users_Invited_Counter;j++) {
							if(user.User_Events.get(i).Users_Invited()[j]==user) {
								System.out.println(user.User_Events.get(i).Name+"\n");
							}
						}
					}
					while(loop==false) {
						System.out.println("Press 1 to Edit your Event Invitation\n"+
								   "Press 2 to go to Main Menu\n");
						int choice= scan.nextInt();
						if(choice==1) {
							System.out.println("All Events: \n");
							user.View_Events(user);
							Boolean loop2=false;
							while(loop2==false) {
								System.out.println("Please enter the event name: \n");
								String event=scan.nextLine();
								for(int i=0;i<user.User_Events.size();i++) {
									if(user.User_Events.get(i).Name.equals(event)) {
										user.Edit_EventInvitation(user, user.User_Events.get(i));
										loop2=true;
									}
								}
								if(loop2==false) {
									System.out.println("Not an available event.Please retry. \n");
								}
							}
							loop=true;
						}else if(choice==2) {
							loop=true;
						}else {
							System.out.println("Not an available option.Please retry. \n");
						}
					}
				}else if(option==9){
					while(loop==false) {
						System.out.println("Please enter the Name of the user to send Message to: \n");
						String name=scan.nextLine();
						name=scan.nextLine();
						for(int i=0;i<user.BelongToDepartment.get_Users().size();i++) {
							if(user.BelongToDepartment.get_Users().get(i).get_Name().equals(name)) {
								user.Send_Message(user, user.BelongToDepartment.get_Users().get(i));
								loop=true;
							}
						}
						if(loop==false) {
							System.out.println("You entered wrong Name.Please retry. \n");
						}
					}
				}else if(option==10){
					while(loop==false) {
						System.out.println("Please enter the Name of the user to view message history: \n");
						String name=scan.nextLine();
						name=scan.nextLine();
						for(int i=0;i<user.BelongToDepartment.get_Users().size();i++) {
							if(user.BelongToDepartment.get_Users().get(i).get_Name().equals(name)) {
								user.View_Message_History(user, user.BelongToDepartment.get_Users().get(i));
								loop=true;
							}
						}
						if(loop==false) {
							System.out.println("You entered wrong Name or there is no Message History with this User.Please retry. \n");
						}
					}
				}else if(option==11){
					user.View_Department_Announcements(user);
				}else if(option==12){
					((Teacher) user).View_Lessons(); 
					while(loop==false) {
						System.out.println("Please enter the Name of the Lesson: \n");
						String name=scan.nextLine();
						name=scan.nextLine();
						for(int i=0;i<((Teacher)user).Lessons.size();i++) {
							if(((Teacher)user).Lessons.get(i).Name.equals(name)) {
								((Teacher)user).View_Lesson_Announcements(user, ((Teacher)user).Lessons.get(i));
								Boolean inner=false;
								while(inner==false) {
									System.out.println("Press 1 to Create an Announcement\n"+
												"Press 2 to Edit an Announcement\n"+
												"Press 3 to Create an Assignment\n"+
												"Press 4 to Edit an Assignment\n"+
												"Press 5 to Edit Lesson's Info\n"+
											    "Press 6 to go to Main Menu\n");
									int choice= scan.nextInt();
									if(choice==1) {
										((Teacher)user).Create_Lesson_Announcement(((Teacher)user).Lessons.get(i));
									}else if(choice==2) {
										for(int v=0;v<((Teacher)user).Lessons.get(i).Lesson_Announcements_Counter;v++) {
											System.out.println(((Teacher)user).Lessons.get(i).Lesson_Announcements[v].Title+" \n");
										}
										Boolean loop2=false;
										while(loop2==false) {
											System.out.println("Please enter the Announcement's Title name: \n");
											String title=scan.nextLine();
											for(int x=0;x<((Teacher)user).Lessons.get(i).Lesson_Announcements_Counter;x++) {
												if(((Teacher)user).Lessons.get(i).Lesson_Announcements[x].Title.equals(title)) {
													loop2=true;
													((Teacher)user).Edit_Announcement(((Teacher)user).Lessons.get(i).Lesson_Announcements[x]);
												}
											}
											if(loop2==false) {
												System.out.println("You entered wrong Title.Please retry. \n");
											}
										}
									}else if(choice==3) {
										((Teacher)user).Create_Assignment(((Teacher)user).Lessons.get(i));
									}else if(choice==4) {
										for(int k=0;k<((Teacher) user).Lessons.get(i).Assignment_Counter;k++) {
											System.out.println(((Teacher)user).Lessons.get(i).Assignments[k].Name+" \n");
										}
										Boolean loop4=false;
										while(loop4==false) {
											System.out.println("Please enter the Assignment's name: \n");
											String title=scan.nextLine();
											for(int x=0;x<((Teacher)user).Lessons.get(i).Assignment_Counter;x++) {
												if(((Teacher)user).Lessons.get(i).Assignments[x].Name.equals(title)) {
													loop4=true;
													((Teacher)user).Edit_Assignment(((Teacher)user).Lessons.get(i).Assignments[x]);
												}
											}
											if(loop4==false) {
												System.out.println("You entered wrong Name.Please retry. \n");
											}
										}
									}else if(choice==5) {
										((Teacher)user).Edit_Lesson_Info(((Teacher)user).Lessons.get(i));
									}else if(choice==6) {
										inner=true;
									}else {
										System.out.println("Not an available option.Please retry. \n");
									}
								}
								loop=true;
							}
						}
						if(loop==false) {
							System.out.println("You have not enrolled in this lesson.Please retry. \n");
						}
					}
				}else if(option==13){
					System.out.println("Your Department's Lessons: \n");
					for(int i=0;i<user.BelongToDepartment.get_Lessons().size();i++) {
						System.out.println(user.BelongToDepartment.get_Lessons().get(i).Name+"\n");
					}
				}else if(option==14){
					((Teacher) user).View_Lessons();
					while(loop==false) {
						System.out.println("Press 1 to View a Lesson's Grades and Submissions\n"+
								   "Press 2 to go to Main Menu\n");
						int choice= scan.nextInt();
						if(choice==1) {
							Boolean loop2=false;
							while(loop2==false) {
								System.out.println("Please enter the Lesson's name: \n");
								String lesson=scan.nextLine();
								for(int i=0;i<((Teacher) user).Lessons.size();i++) {
									if(((Teacher) user).Lessons.get(i).Name.equals(lesson)) {
										((Teacher) user).View_Lesson_Students(((Teacher) user).Lessons.get(i));
										((Teacher) user).View_Grades(((Teacher) user).Lessons.get(i));
										for(int k=0;k<((Teacher) user).Lessons.get(i).Assignment_Counter;k++) {
											for(int l=0;l<((Teacher) user).Lessons.get(i).Assignments[k].Submissions_Counter;l++) {
												System.out.println(((Teacher) user).Lessons.get(i).Assignments[k].Submissions[l].student.AM_Number+" \n");
											}
										}
										loop2=true;
									}
								}
								if(loop2==false) {
									System.out.println("Not an available lesson.Please retry. \n");
								}
							}
							loop=true;
						}else if(choice==2) {
							loop=true;
						}else {
							System.out.println("Not an available option.Please retry. \n");
						}
					}
				}else if(option==15){
					break_big_loop=true;
					user.LogOut(user);
					scan.close();
				}else{
					System.out.println("Not an available option.Please retry. \n");
				}
				}
		//secretariat	
		}else {
			while(break_big_loop==false){
				loop=false;
				System.out.println("Press 1 to View your Profile\n"+
								   "Press 2 to Search Lessons or Users\n"+
								   "Press 3 to Create an Event\n"+
								   "Press 4 to View your Events\n"+
								   "Press 5 to Edit an Event\n"+
								   "Press 6 to View Users Online\n"+
								   "Press 7 to View Notifications\n"+
								   "Press 8 to View Event Invitations\n"+
								   "Press 9 to Send a Message to a User\n"+
								   "Press 10 to View Message History\n"+
								   "Press 11 to View your Department's Announcements\n"+
								   "Press 12 to View your Department's Lessons\n"+
								   "Press 13 to View University's Departments\n"+
								   "Press 14 to Confirm a Skill\n"+
								   "Press 15 to Logout\n"+
								   "Please enter your choice:\n");
				int option= scan.nextInt();
				if(option==1){
					user.View_My_Profile();
					((Secretariat) user).View_My_Profile();
					while(loop==false) {
						System.out.println("Press 1 to Edit your Profile\n"+
								   "Press 2 to go to Main Menu\n");
						int choice= scan.nextInt();
						if(choice==1) {
							user.Edit_Profile(user);
							((Secretariat) user).Edit_Profile_S((Secretariat)user);
							loop=true;
						}else if(choice==2) {
							loop=true;
						}else {
							System.out.println("Not an available option.Please retry. \n");
						}
					}
				}else if(option==2){
					System.out.println("Please enter a keyword(Name) to search a User or Lesson: \n");
					String Keyword=scan.nextLine();
					Keyword=scan.nextLine();
					user.Search(Keyword);
					Boolean loop3=false;
					while(loop3==false) {
						System.out.println("If you want to View the profile of a User press 1 or else press 2. \n");
						int choice= scan.nextInt();
						if(choice==1) {
							Boolean search=false;
							while(search==false) {
							System.out.println("Please enter the email of the User: \n");
							Keyword=scan.nextLine();
							Keyword=scan.nextLine();
							User tmp=University.find_Another_User(Keyword);
							if(tmp!=null) {
								loop3=true;
								user.View_User_Profile(tmp);
								search=true;
							}else {
								System.out.println("Please retry. \n");
							}
							}
						}else if(choice==2) {
							loop3=true;
						}else {
							System.out.println("Not an available option.Please retry. \n");
						}
					}
					while(loop==false) {
						System.out.println("If you want to Search again press 1 or press 2 to Main Menu. \n");
						int choice= scan.nextInt();
						if(choice==1) {
							System.out.println("Please enter a keyword to search a User or Lesson: \n");
							Keyword=scan.nextLine();
							Keyword=scan.nextLine();
							user.Search(Keyword);
							loop=true;
						}else if(choice==2) {
							loop=true;
						}else {
							System.out.println("Not an available option.Please retry. \n");
						}
					}
				}else if(option==3){
					user.Create_Event(user);
				}else if(option==4){
					user.View_Events(user);
				}else if(option==5){
					user.View_Events(user);
					while(loop==false) {
						System.out.println("Please enter an event to edit: \n");
						String event=scan.nextLine();
						event=scan.nextLine();
						for(int i=0;i<user.User_Events.size();i++) {
							if(user.User_Events.get(i).Name.equals(event)) {
								user.Edit_Event(user, user.User_Events.get(i));
								loop=true;
							}
						}
						if(loop==false) {
							System.out.println("You entered wrong Event name.Please retry. \n");
						}
					}
				}else if(option==6){
					user.View_Users_Online();
				}else if(option==7){
					user.View_Notifications(user);
				}else if(option==8){
					System.out.println("Invitations: \n");
					for(int i=0;i<user.User_Events.size();i++) {
						for(int j=0;j<user.User_Events.get(i).Users_Invited_Counter;j++) {
							if(user.User_Events.get(i).Users_Invited()[j]==user) {
								System.out.println(user.User_Events.get(i).Name+"\n");
							}
						}
					}
					while(loop==false) {
						System.out.println("Press 1 to Edit your Event Invitation\n"+
								   "Press 2 to go to Main Menu\n");
						int choice= scan.nextInt();
						if(choice==1) {
							System.out.println("All Events: \n");
							user.View_Events(user);
							Boolean loop2=false;
							while(loop2==false) {
								System.out.println("Please enter the event name: \n");
								String event=scan.nextLine();
								for(int i=0;i<user.User_Events.size();i++) {
									if(user.User_Events.get(i).Name.equals(event)) {
										user.Edit_EventInvitation(user, user.User_Events.get(i));
										loop2=true;
									}
								}
								if(loop2==false) {
									System.out.println("Not an available event.Please retry. \n");
								}
							}
							loop=true;
						}else if(choice==2) {
							loop=true;
						}else {
							System.out.println("Not an available option.Please retry. \n");
						}
					}
				}else if(option==9){
					while(loop==false) {
						System.out.println("Please enter the Name of the user to send Message to: \n");
						String name=scan.nextLine();
						name=scan.nextLine();
						for(int i=0;i<user.BelongToDepartment.get_Users().size();i++) {
							if(user.BelongToDepartment.get_Users().get(i).get_Name().equals(name)) {
								user.Send_Message(user, user.BelongToDepartment.get_Users().get(i));
								loop=true;
							}
						}
						if(loop==false) {
							System.out.println("You entered wrong Name.Please retry. \n");
						}
					}
				}else if(option==10){
					while(loop==false) {
						System.out.println("Please enter the Name of the user to view message history: \n");
						String name=scan.nextLine();
						name=scan.nextLine();
						for(int i=0;i<user.BelongToDepartment.get_Users().size();i++) {
							if(user.BelongToDepartment.get_Users().get(i).get_Name().equals(name)) {
								user.View_Message_History(user, user.BelongToDepartment.get_Users().get(i));
								loop=true;
							}
						}
						if(loop==false) {
							System.out.println("You entered wrong Name or there is no Message History with this User.Please retry. \n");
						}
					}
				}else if(option==11){
					user.View_Department_Announcements(user);
					while(loop==false) {
						System.out.println("Press 1 to Edit an Announcement\n"+
									"Press 2 to Create an Announcement\n"+
								   "Press 3 to go to Main Menu\n");
						int choice= scan.nextInt();
						if(choice==1) {
							Boolean loop2=false;
							while(loop2==false) {
								System.out.println("Please enter the Announcement Title: \n");
								String title=scan.nextLine();
								title=scan.nextLine();
								for(int i=0;i<user.BelongToDepartment.get_Announcements().size();i++) {
									if(user.BelongToDepartment.get_Announcements().get(i).Title.equals(title)) {
										((Secretariat)user).Edit_Announcement(user.BelongToDepartment.get_Announcements().get(i));
										loop2=true;
									}
								}
								if(loop2==false) {
									System.out.println("Not an available Announcement.Please retry. \n");
								}
							}
							
						}else if(choice==2) {
							((Secretariat)user).Create_Announcement();
						}else if(choice==3) {
							loop=true;
						}else {
							System.out.println("Not an available option.Please retry. \n");
						}
					}
				}else if(option==12){
					System.out.println("Your Department's Lessons: \n");
					for(int i=0;i<user.BelongToDepartment.get_Lessons().size();i++) {
						System.out.println(user.BelongToDepartment.get_Lessons().get(i).Name+"\n");
					}
				}else if(option==13){
					((Secretariat)user).View_Departments();
					while(loop==false) {
						System.out.println("Press 1 to Create a User\n"+
									"Press 2 to Edit a User\n"+
									"Press 3 to Create a Lesson\n"+
									"Press 4 to Edit a Lesson\n"+
								   "Press 5 to go to Main Menu\n");
						int choice= scan.nextInt();
						if(choice==1) {
							((Secretariat)user).Create_User();
						}else if(choice==2) {
							Boolean loop2=false;
							while(loop2==false) {
								System.out.println("Please enter the email of the User: \n");
								String email=scan.nextLine();
								email=scan.nextLine();
								for(int i=0;i<University.Department_counter;i++) {
									for(int j=0;j<University.Departments[i].get_Users().size();j++) {
										if(University.Departments[i].get_Users().get(j).get_Email().equals(email)) {
											((Secretariat)user).Edit_User(University.Departments[i].get_Users().get(j));
											loop2=true;
										}
									}
								}
								if(loop2==false) {
									System.out.println("Not an available User.Please retry. \n");
								}
							}
						}else if(choice==3) {
							((Secretariat)user).Create_Lesson();
						}else if(choice==4) {
							Boolean loop2=false;
							while(loop2==false) {
								System.out.println("Please enter the Lesson to edit: \n");
								String name=scan.nextLine();
								for(int i=0;i<University.Department_counter;i++) {
									for(int j=0;j<University.Departments[i].get_Lessons().size();j++) {
										if(University.Departments[i].get_Lessons().get(j).Name.equals(name)) {
											((Secretariat)user).Edit_Lesson(University.Departments[i].get_Lessons().get(j));
											loop2=true;
										}
									}
								}
								if(loop2==false) {
									System.out.println("Not an available Lesson.Please retry. \n");
								}
							}
						}else if(choice==5) {
							loop=true;
						}else {
							System.out.println("Not an available option.Please retry. \n");
						}
					}
				}else if(option==14){
					for(int j=0;j<((Secretariat)user).Pending_Skills_Counter;j++) {
						System.out.println(((Secretariat)user).Pending_Skills[j]+" \n");
					}
					((Secretariat)user).Confirm_Skill();
				}else if(option==15){
					break_big_loop=true;
					user.LogOut(user);
					scan.close();
				}else{
					System.out.println("Not an available option.Please retry. \n");
				}
				}
			
		}
		scan.close();
		return;
	}
//---------------------------------------------------------------------


	
	
	
	
	
	//Login
	//---------------------------------------------------------------------
		public void LogIn(){
			Scanner scan = new Scanner(System.in);
			Boolean right_choice=true;
			Boolean validation;
			int count_tries=0;
			User tmp_User=null;
			String Username1 = "";
			while (right_choice==true && count_tries<=3){
				System.out.println("Welcome to PAPI-Eclass! Please press 1 to enter or 2  in case you forgot your password. \n");
				String enter_choice= scan.nextLine();
				if( enter_choice.equals("1")){
					System.out.println("Username: \n");
					String Username= scan.nextLine();
					//Username=scan.nextLine();
					System.out.println("Password: \n");
					String Password= scan.nextLine();
					Username1=Username;
					//validate
					 tmp_User=University.find_Current_User(Username);
					 if(tmp_User==null) {
						 System.out.println("No such user exists.");
						 continue;
					 }
					if(tmp_User.get_Is_Active()==false) {
						System.out.println("Account Inactive. \n");
						scan.close();
						return;
						
					}
					if(tmp_User.get_Is_Locked()==true) {
						System.out.println("Your account is locked due to many login attempts. Please enter your email and request unlock. \n");
						String Email2= scan.nextLine();
						if(Email2!=null){                       //watch out for this condition, might not work wherever there is null
							tmp_User.Request_Unlock(tmp_User,Email2);
							System.out.println("Unlock account requested.We will make contact with as soon as possible. \n");
							scan.close();
							return;
					}
					}
					validation=tmp_User.BelongToDepartment.Validate(tmp_User,Password);  //tha xreiastei allagi ? epidi exoume idi to xristi tmp_User
					if(validation==true){
						System.out.println("Welcome "+Username);
						right_choice=false;
					}else{
						System.out.println("Not valid credentials.Please retry. \n");
						System.out.println("Tries Left:"+ (3-count_tries));
						count_tries=count_tries+1;
					}
				}else if(enter_choice.equals("2")){
					//send email
					System.out.println("Please enter your email: \n");
					String Email= scan.nextLine();
					if(Email!=null){
					tmp_User.BelongToDepartment.Send_New_Password(Email);
					System.out.println("Password sent to:"+Email);
					System.out.println("Please retry to enter. \n");
					}
				}else{
					System.out.println("Not a supported choice.Please retry. \n");
				}
			}
			if(count_tries>3){
				//lock
				tmp_User.set_Is_Locked(true);
				System.out.println("Your account is locked due to many login attempts. Please enter your email and request unlock. \n");
				String Email2= scan.nextLine();
				if(Email2!=null){
					tmp_User.Request_Unlock(tmp_User,Email2);
					System.out.println("Unlock account requested.We will make contact with as soon as possible. \n");
				}
				scan.close();
				return;
			}else{
				tmp_User.set_Is_Online(true);
				University.Home(University.find_Current_User(Username1));  //tha mporousame tmp_User???
			}
			scan.close();
			return;
		}
	//----------------------------------------------------------------------------------------------	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
