package Model;

import java.io.File;

public class Submission {

	Student student;
	File file;
	
	
	
//Constructor
//-----------------------------------------------------------------------------------------------------------------------------
	public Submission(Student student, File file) {
		this.file=file;
		this.student=student;
	}
//------------------------------------------------------------------------------------------------------------------------------
			
	
	
//set methods
//------------------------------------------------------------------------------------------------------
	public void set_Student(Student student){	
		this.student=student;
	}
	
	
	public void set_File(File file){	
		this.file=file;
	}
//-------------------------------------------------------------------------------------------------------
	
//get methods
//------------------------------------------------------------------------------------------------------
	public Student get_Student(){	
		return student;
	}
		
		
	public File get_File(){	
		return file;
	}
//-------------------------------------------------------------------------------------------------------	
	
	
}
