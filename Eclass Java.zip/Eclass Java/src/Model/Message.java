package Model;

public class Message {

	public User[] Users;
	public String[] message;
	public int Message_Counter;
	public int User_Counter;
	
	
//Constructor
//-------------------------------------------------------------------------------------
	public Message (){               //i Message(User[] Users,String[] message)
		this.Users=new User[2];     //check value!!! is it right practice???
		this.message=new String[10000];
	}
//---------------------------------------------------------------------------------------


//set methods
//------------------------------------------------------------------------------------------------------
	public void set_Users(User user){	
		this.Users[this.User_Counter]=user;
		this.User_Counter=this.User_Counter+1;
	}
	
	public void set_Message(String message){	
		this.message[this.Message_Counter]=message;
		this.Message_Counter=this.Message_Counter+1;
	}
//---------------------------------------------------------------------------------------------------------


//get methods
//---------------------------------------------------------------------------------------------------------
	public User[] get_Users(){
		return Users;
	}
	
	public String[] get_Messages(){
		return message;
	}
//---------------------------------------------------------------------------------------------------------
	
	
}
