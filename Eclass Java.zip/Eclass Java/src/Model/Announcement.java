package Model;

import java.util.Date;

public class Announcement {

	public String Title;
	public String Description;
	public String[] Comments;
	public int Comments_Counter;
	public Date date;
	public int Announcement_ID;
	private static int Announcement_ID_Counter=0;
	public User User_Created;
	
	
//Constructor
//-------------------------------------------------------------------------------------
	public Announcement(String Title,String Description){               //
			this.Announcement_ID=Announcement_ID_Counter + 1;
			this.Title=Title;
			//this.date=date;
			this.Description=Description;
		}
//---------------------------------------------------------------------------------------


//set methods
//------------------------------------------------------------------------------------------------------
	public void set_Comments(String comment){	
		this.Comments[this.Comments_Counter]=comment;
		this.Comments_Counter=this.Comments_Counter+1;
	}
	
	public void set_Title(String Title){	
		this.Title=Title;
	}
	
	public void set_Description(String Description){	
		this.Description=Description;
	}
	
	public void set_Date(Date date){	
		this.date=date;
	}
	
	void set_User_Created(User User_Created) {
		this.User_Created=User_Created;
	}
//---------------------------------------------------------------------------------------------------------


//get methods
//---------------------------------------------------------------------------------------------------------
	public	String[] get_Comments(){
		return Comments;
	}
	
	public	String get_Title(){
		return Title;
	}
	
	public	String get_Description(){
		return Description;
	}
	
	public	Date get_Date(){
		return date;
	}
	
	public User User_Created() {
		return User_Created;
	}
//---------------------------------------------------------------------------------------------------------
	
	
	
}
