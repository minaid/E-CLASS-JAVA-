package Model;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.TimeZone;

public class Teacher extends User{

	public String Surname;
	public List<Lesson> Lessons;
	public Date DOB;
	public String[] Skills;
	public int Skills_Counter;
	public String[] Languages;
	public int Languages_Counter;
	public String Education;
	public String Teacher_Title;
	public String Office_Hours;
	public String Office;
	
//Constructor
//-----------------------------------------------------------------------------------------------------------------------------
	public Teacher(String Username, String Password, String Email, String Name,String Surname,
			Boolean Notification_enabled, Boolean Is_Locked, Boolean Is_Active, Department BelongToDepartment,
			TimeZone GMT, Boolean Is_Online) {
		super(Username, Password, Email, Name, Notification_enabled, Is_Locked, Is_Active, BelongToDepartment, GMT, Is_Online);
		this.Surname=Surname;
		this.Lessons = new ArrayList<Lesson>();
		// TODO Auto-generated constructor stub
	}
//-----------------------------------------------------------------------------------------------------------------------------

	
//Abstract Method
//--------------------------------------------------------------------------------
	@Override
	void Temp() {
		// TODO Auto-generated method stub
	}
//---------------------------------------------------------------------------------
	
	
//set methods
//------------------------------------------------------------------------------------------------------
	public void set_Surname(String Surname){	
		this.Surname=Surname;
	}
	
	public void set_Lessons(Lesson lesson){	
		this.Lessons.add(lesson);
	}
	
	public void set_DOB(Date DOB){	
		this.DOB=DOB;
	}
	
	public void set_Skills(String skill){	
		this.Skills[this.Skills_Counter]=skill;
		this.Skills_Counter=this.Skills_Counter+1;
	}
	
	public void set_Languages(String language){	
		this.Languages[this.Languages_Counter]=language;
		this.Languages_Counter=this.Languages_Counter+1;
	}
	
	public void set_Education(String Education){	
		this.Education=Education;
	}
	
	public void set_Teacher_Title(String Teacher_Title){	
		this.Teacher_Title=Teacher_Title;
	}
	
	public void set_Office_Hours(String Office_Hours){	
		this.Office_Hours=Office_Hours;
	}
	
	public void set_Office(String Office){	
		this.Office=Office;
	}
//---------------------------------------------------------------------------------------------------------


//get methods
//---------------------------------------------------------------------------------------------------------							
	public String get_Surname() {
		return Surname;
	}
	
	public	List<Lesson> get_Lessons(){
		return Lessons;
	}
	
	public	Date get_DOB(){
		return DOB;
	}
	
	public String[] get_Skills() {
		return Skills;
	}
	
	public String[] get_Languages() {
		return Languages;
	}
	
	public String get_Education() {
		return Education;
	}
	
	public String get_Teacher_Title() {
		return Teacher_Title;
	}
	
	public String get_Office_Hours() {
		return Office_Hours;
	}
	
	public String get_Office() {
		return Office;
	}
//---------------------------------------------------------------------------------------------------------		
						
							
							
//View My Profile						
//---------------------------------------------------------------------------------------------------------
	public void View_My_Profile() {
	System.out.println("Surname: "+ Surname+" \n");
	System.out.println("Office: "+ Office+" \n");
	System.out.println("Office Hours: "+ Office_Hours+" \n");
	System.out.println("Date of Birth: "+ DOB+" \n");
	System.out.println("Title: "+ Teacher_Title+" \n");
	System.out.println("Current Education: "+ Education+" \n");
	for(int i=0;i<Skills_Counter;i++) {
	System.out.println("Skill: "+ Skills[i]+" \n");
	}
	for(int j=0;j<Skills_Counter;j++) {
		System.out.println("Language: "+ Languages[j]+" \n");
	}
	System.out.println("Number of Lessons: "+ Lessons.size()+" \n");
	}
//--------------------------------------------------------------------------------------------------------							
							

//Edit Profile						
//-------------------------------------------------------------------------------------------------------						
	public void Edit_Profile2(Teacher Current_User) {
		Boolean loop=false;
		Boolean break_big_loop=false;
		Scanner scan = new Scanner(System.in);
		while(break_big_loop==false){
		System.out.println("Press 1 to change your Skills\n"+
						   "Press 2 to change your Languages\n"+
						   "Press 3 to change your Education\n"+
						   "Press 4 to change your Office\n"+
						   "Press 5 to change your Office Hours\n"+
						   "Press 6 to Exit\n");
		int option= scan.nextInt();
		if(option==1){
			System.out.println("Current Skills:  \n");
			for(int i=0;i<Skills_Counter;i++) {
				System.out.println("Skill: "+ Skills[i]+" \n");
			}
			while(loop==false) {
				System.out.println("Press 1 to change your current Skills\n"+
						   "Press 2 to enter a new skill\n");
				int choice1= scan.nextInt();
				if(choice1==1) {
					Boolean loop1=false;
					int count_skill=0;
					while(loop1==false) {
						System.out.println("Please enter the skill you want to change: \n");
						String old_skill=scan.nextLine();
						for(int w=0;w<Skills_Counter;w++) {
							if(Skills[w].equals(old_skill)) {
								System.out.println("New Skill: \n");
								String skill= scan.nextLine();
								Skills[w]=skill;
								count_skill=1;
								loop1=true;
							}
						}
						if(count_skill==0) {
							System.out.println("Not a current skill that you have.Please retry. \n");
						}
					}
					loop=true;
				}else if(choice1==2) {
					System.out.println("New Skill: \n");
					String skill= scan.nextLine();
					Boolean check=false;
					for(int j=0;j<University.Global_Skils_Counter;j++) {
						if(University.Global_Skils[j].equals(skill)) {
							check=true;
						}
					}
					if(check==true) {
						Skills[Skills_Counter]=skill;
						Skills_Counter=Skills_Counter+1;
						loop=true;
					}else {
						this.BelongToDepartment.secretariat.Pending_Skills[this.BelongToDepartment.secretariat.Pending_Skills_Counter]=skill;
						this.BelongToDepartment.secretariat.Pending_Skills_Counter=this.BelongToDepartment.secretariat.Pending_Skills_Counter+1;
						loop=true;
						System.out.println("Skill Suggested. \n");
					}
					
				}else {
					System.out.println("Not an available option.Please retry. \n");
				}
			}
			System.out.println("Changes made. \n");
		}else if(option==2){
			System.out.println("Current Languages:  \n");
			for(int i=0;i<Languages_Counter;i++) {
				System.out.println("Language: "+ Languages[i]+" \n");
			}
			while(loop==false) {
				System.out.println("Press 1 to change your current Languages\n"+
						   "Press 2 to enter a new Language\n");
				int choice2= scan.nextInt();
				if(choice2==1) {
					Boolean loop1=false;
					int count_lang=0;
					while(loop1==false) {
						System.out.println("Please enter the language you want to change: \n");
						String old_lang=scan.nextLine();
						for(int w=0;w<Languages_Counter;w++) {
							if(Languages[w].equals(old_lang)) {
								System.out.println("New Language: \n");
								String lang= scan.nextLine();
								Languages[w]=lang;
								count_lang=1;
								loop1=true;
							}
						}
						if(count_lang==0) {
							System.out.println("Not a current Language that you have.Please retry. \n");
						}
					}
					loop=true;
				}else if(choice2==2) {
					System.out.println("New Language: \n");
					String lang= scan.nextLine();
					Languages[Languages_Counter]=lang;
					Languages_Counter=Languages_Counter+1;
					loop=true;
				}else {
					System.out.println("Not an available option.Please retry. \n");
				}
			}
			System.out.println("Changes made. \n");
		}else if(option==3){
			System.out.println("Current Education: "+ Education+" \n");
			System.out.println("New Education: \n");
			String education= scan.nextLine();
			Current_User.Education=education;
			System.out.println("Changes made. \n");
		}else if(option==4){
			System.out.println("Current Office: "+ Office+" \n");
			System.out.println("New Office: \n");
			String office= scan.nextLine();
			Current_User.Office=office;
		}else if(option==5){
			System.out.println("Current Office Hours: "+ Office_Hours+" \n");
			System.out.println("New Office Hours: \n");
			String hours= scan.nextLine();
			Current_User.Office_Hours=hours;
		}else if(option==6){
			break_big_loop=true;
			System.out.println("Exit.");
			//scan.close();
			return;
		}else{
			System.out.println("Not an available option.Please retry. \n");
		}
		}
		
		//scan.close();
		return;
	}
//--------------------------------------------------------------------------------------------------------								
							
													
													
//Suggest Skill
//---------------------------------------------------------------------------------------------------------
	public void Suggest_Skill(String Skill) {		
		Secretariat secretariat=this.BelongToDepartment.get_Secretariat();
		secretariat.Pending_Skills[secretariat.Pending_Skills_Counter]=Skill;
		secretariat.Pending_Skills_Counter=secretariat.Pending_Skills_Counter+1;
	}
//---------------------------------------------------------------------------------------------------------


//View lessons
//---------------------------------------------------------------------------------------------------------
	public void View_Lessons() {
		System.out.println("Your current Lessons: \n");
		for(int i=0;i<this.Lessons.size();i++) {
			System.out.println(this.Lessons.get(i).Name +"\n");
		}		
	}
//---------------------------------------------------------------------------------------------------------
							

//View Grades
//---------------------------------------------------------------------------------------------------------
	public void View_Grades(Lesson lesson) {
		for(int k=0;k<this.Lessons.size();k++) {
			if(lesson==this.Lessons.get(k)) {
				System.out.println("Assignment grades for the lesson: "+lesson.Name+ "\n");
				for(int i=0;i<lesson.Assignment_Counter;i++) {
					for(int j=0;j<lesson.Assignments[i].Grades_Counter;j++) {
							System.out.println("For assignment: "+lesson.Assignments[i].Name+ "\n");
							System.out.println(lesson.Assignments[i].Grades[j].grade + "\n");
							System.out.println(lesson.Assignments[i].Grades[j].student.AM_Number + "\n");
					}
					
				}
				
				System.out.println("Total grades for the lesson: "+lesson.Name+ "\n");
				for(int w=0;w<lesson.Grades_Counter;w++) {
						System.out.println(lesson.Grades[w].grade + "\n");
						System.out.println(lesson.Grades[w].student.AM_Number + "\n");
				}
				return;
			}
		}
		
		System.out.println("Lesson: "+lesson.Name+ " is not a lesson your assigned to.\n");
	}
//---------------------------------------------------------------------------------------------------------
							
	

//Create Lesson Announcement
//---------------------------------------------------------------------------------------------------------
	public void Create_Lesson_Announcement(Lesson lesson) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Please enter the Title for the Announcement: \n");
		String title= scan.nextLine();
		System.out.println("Please enter the Description for the Announcement: \n");
		String description= scan.nextLine();
		lesson.Lesson_Announcements[lesson.Lesson_Announcements_Counter]=new Announcement(title,description);       //i mporei me teleia kai meta kathe attribute
		lesson.Lesson_Announcements_Counter=lesson.Lesson_Announcements_Counter+1;
		//scan.close();
		System.out.println("Announcement Created!\n");
	}
//---------------------------------------------------------------------------------------------------------
			
			
//Grade Student
//---------------------------------------------------------------------------------------------------------
	public void Grade_Student(Lesson lesson,Student student, int grade) {
				lesson.Grades[lesson.Grades_Counter].grade=grade;
				lesson.Grades[lesson.Grades_Counter].student=student;
				lesson.Grades_Counter=lesson.Grades_Counter+1;
	}
			
//---------------------------------------------------------------------------------------------------------			
			

//Edit Grade
//---------------------------------------------------------------------------------------------------------
	public void Edit_Grade(Lesson lesson,Student student, int grade) {
		for(int i=0;i<lesson.Grades_Counter;i++) {
			if(lesson.Grades[i].student==student) {
				lesson.Grades[i].grade=grade;
				break;
			}
		}
	}
//---------------------------------------------------------------------------------------------------------

			
//Grade Assignment
//---------------------------------------------------------------------------------------------------------
	public void Grade_Assignment(Student student, int grade,Assignment assignment) {
				assignment.Grades[assignment.Grades_Counter].student=student;
				assignment.Grades[assignment.Grades_Counter].grade=grade;
				assignment.Grades_Counter=assignment.Grades_Counter + 1;
	}					
//---------------------------------------------------------------------------------------------------------					
			

//Edit Grade Assignment
//---------------------------------------------------------------------------------------------------------
	public void Edit_Grade_Assignment(Student student, int grade,Assignment assignment) {
		for(int i=0;i<assignment.Grades_Counter;i++) {
			if(assignment.Grades[i].student==student) {
				assignment.Grades[i].grade=grade;
				break;
			}
		}
	}
//---------------------------------------------------------------------------------------------------------			
			
			
			
//Create Assignment
//---------------------------------------------------------------------------------------------------------			
	public void Create_Assignment(Lesson lesson) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Please enter the Name for the Assignment: \n");
		String Name= scan.nextLine();
		System.out.println("Please enter the Description for the Assignment: \n");
		String Description= scan.nextLine();
		LocalDate localDate = LocalDate.now();
		System.out.println("Please enter the End Date for the Assignment: \n");
		String Date_Ending2= scan.nextLine();
		//LocalDate Date_Ending1 = dateFormat.parse(Date_Ending2);        //FIX!!!!!!!!!!!!!!!
		lesson.Assignments[lesson.Assignment_Counter].Name=Name;     //i mporei me new Assignment();
		lesson.Assignments[lesson.Assignment_Counter].Description=Description;
		lesson.Assignments[lesson.Assignment_Counter].Date_Starting=localDate;
		lesson.Assignments[lesson.Assignment_Counter].Date_Ending=localDate; //FIX!!!!!!!!!!!!!!!
		lesson.Assignments[lesson.Assignment_Counter].Status=true;
		lesson.Assignments[lesson.Assignment_Counter].lesson=lesson;
		lesson.Assignment_Counter=lesson.Assignment_Counter+1;
		//scan.close();
		System.out.println("Assignment Created!\n");
	}
//---------------------------------------------------------------------------------------------------------		
			
			
//Edit Assignment
//---------------------------------------------------------------------------------------------------------
	public void Edit_Assignment(Assignment assignment) {
		Scanner scan = new Scanner(System.in);
		Boolean break_big_loop=false;
		while(break_big_loop==false){
		System.out.println("Press 1 to change the Name\n"+
				   "Press 2 to change the Description\n"+
				   "Press 3 to change the End Date\n"+
				   "Press 4 to Exit\n");
		int option= scan.nextInt();
		if(option==1){
			System.out.println("Please enter the Name for the Assignment: \n");
			String Name= scan.nextLine();
			assignment.Name=Name; 
		}else if(option==2) {
			System.out.println("Please enter the Description for the Assignment: \n");
			String Description= scan.nextLine();
			assignment.Description=Description;
		}else if(option==3) {
			System.out.println("Please enter the End Date for the Assignment: \n");
			String Date_Ending2= scan.nextLine();
			//LocalDate Date_Ending1 = dateFormat.parse(Date_Ending2);        //FIX!!!!!!!!!!!!!!!
			//assignment.Date_Ending=localDate; //FIX!!!!!!!!!!!!!!!
		}else if(option==4) {
			break_big_loop=true;
			//scan.close();
			System.out.println("Assignment Edited!\n");
			return;
		}else {
			System.out.println("Not an available option.Please retry. \n");
		}
		}
		//scan.close();
		System.out.println("Assignment Edited!\n");
	}		
//---------------------------------------------------------------------------------------------------------
		
			
//Edit Announcement
//---------------------------------------------------------------------------------------------------------
	public void Edit_Announcement(Announcement announcement) {
		Scanner scan = new Scanner(System.in);
		Boolean break_big_loop=false;
		while(break_big_loop==false){
		System.out.println("Press 1 to change the Title\n"+
				   "Press 2 to change the Description\n"+
				   "Press 3 to Exit\n");
		int option= scan.nextInt();
		if(option==1){
			System.out.println("Please enter the Title for the Announcement: \n");
			String title= scan.nextLine();
			announcement.Title=title; 
		}else if(option==2) {
			System.out.println("Please enter the Description for the Announcement: \n");
			String description= scan.nextLine();
			announcement.Description=description;
		}else if(option==3) {
			break_big_loop=true;
			//scan.close();
			System.out.println("Announcement Edited!\n");
			return;
		}else {
			System.out.println("Not an available option.Please retry. \n");
		}
		}
		//scan.close();
		System.out.println("Announcement Edited!\n");
	}
//---------------------------------------------------------------------------------------------------------
			
			
//View Submissions
//---------------------------------------------------------------------------------------------------------
	public void View_Submissions(Assignment assignment) {
		for(int i=0;i<assignment.Submissions_Counter;i++) {
			System.out.println("Student "+ assignment.Submissions[i].student.AM_Number +"\n");
			//FILE?
		}
		
	}	
//---------------------------------------------------------------------------------------------------------
			

//Edit Lesson Info
//---------------------------------------------------------------------------------------------------------
	public void Edit_Lesson_Info(Lesson lesson) {
		Scanner scan = new Scanner(System.in);
		Boolean break_big_loop=false;
		while(break_big_loop==false){
		System.out.println("Press 1 to change the Name\n"+
				   "Press 2 to change the Description\n"+
				   "Press 3 to Exit\n");
		int option= scan.nextInt();
		if(option==1){
			System.out.println("Please enter the Name of the Lesson: \n");
			String Name= scan.nextLine();
			lesson.Name=Name;
		}else if(option==2) {
			System.out.println("Please enter the Description of the Lesson: \n");
			String description= scan.nextLine();
			lesson.Description=description;
		}else if(option==3) {
			break_big_loop=true;
			//scan.close();
			System.out.println("Lesson Edited!\n");
			return;
		}else {
			System.out.println("Not an available option.Please retry. \n");
		}
		}
		//scan.close();
		System.out.println("Lesson Edited!\n");
	}
//---------------------------------------------------------------------------------------------------------
			
			
//View Lesson Students
//---------------------------------------------------------------------------------------------------------
	public void View_Lesson_Students(Lesson lesson) {
		for(int i=0;i<lesson.Students.size();i++) {
			System.out.println("Student AM: "+ lesson.Students.get(i).AM_Number +"\n");
			System.out.println("Student: "+ lesson.Students.get(i).get_Name() +" "+ lesson.Students.get(i).Surname +"\n");
		}
	}
//---------------------------------------------------------------------------------------------------------
		
}
