package Model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Lesson {
	public int Lesson_ID;
	private static int Lesson_ID_Counter=0; //logika na mpei sto university + methodos pou au3anei to counter
	public Teacher teacher;
	public String Name;
	public  Department BelongToDepartment;
	public Announcement[] Lesson_Announcements;
	public int Lesson_Announcements_Counter=0;
	public Date date;
	public String Description;
	public List<Student> Students;
	public Assignment[] Assignments;
	public int Assignment_Counter;
	public Event[] Events;
	public int Event_Counter;
	public Grade[] Grades;
	public int Grades_Counter;
	
//Constructor
//------------------------------------------------------------------------------------------------------
	public Lesson(Teacher teacher,String Name,Department BelongToDepartment, String Description){
		this.Lesson_ID=Lesson_ID_Counter + 1;
		this.teacher=teacher;
		this.Name=Name;
		this.date=date;
		this.BelongToDepartment=BelongToDepartment;
		this.Description=Description;
		this.Students=new ArrayList<Student>();
		this.Assignments=new Assignment[10000];
		this.Events=new Event[10000];
		this.Grades=new Grade[1000];
		this.Lesson_Announcements=new Announcement[1000];
	}
//------------------------------------------------------------------------------------------------------	
	
//set methods
//------------------------------------------------------------------------------------------------------
	public void set_Teacher(Teacher teacher){
		this.teacher=teacher;
	}
	
	public void set_Name(String Name){
		this.Name=Name;
	}
	
	public void set_BelongToDepartment(Department BelongToDepartment){
		this.BelongToDepartment=BelongToDepartment;
	}
	
	public void set_Lesson_Announcements(Announcement announcement) {
		this.Lesson_Announcements_Counter=this.Lesson_Announcements_Counter+1;
		this.Lesson_Announcements[this.Lesson_Announcements_Counter]=announcement;
	}
	
	public void set_date(Date date){
		this.date=date;
	}
	
	public void set_Description(String Description){	
		this.Description=Description;
	}
	
	public void set_Students(Student student){	
		this.Students.add(student);
	}
	
	public void set_Assignment(Assignment assignment){	
		this.Assignments[this.Assignment_Counter]=assignment;
		this.Assignment_Counter=this.Assignment_Counter+1;
	}
	
	public void set_Events(Event event){	
		this.Events[this.Event_Counter]=event;
		this.Event_Counter=this.Event_Counter+1;
	}
	
	public void set_Grades(Grade grade){	
		this.Grades[this.Grades_Counter]=grade;
		this.Grades_Counter=this.Grades_Counter+1;
	}
//---------------------------------------------------------------------------------------------------------


//get methods
//---------------------------------------------------------------------------------------------------------
	public Teacher get_Teacher(){
		return teacher;
	}
	
	public String get_Name(){
		return Name;
	}

	public Department get_BelongToDepartment(){
		return BelongToDepartment;
	}
	
	public	Announcement[] get_Lesson_Announcements(){
		
		return Lesson_Announcements;
	}
	
	public Date get_Date(){
		return date;
	}
	
	public String get_Description() {
		return Description;
	}
	
	public List<Student> get_Students(){
		return Students;
	}
	
	public Assignment[] get_Assignments(){
		return Assignments;
	}
	
	public Event[] get_Events(){
		return Events;
	}
	
	public Grade[] get_Grades(){
		return Grades;
	}
//---------------------------------------------------------------------------------------------------------
}
