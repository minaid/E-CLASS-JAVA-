package Model;

public class Grade {

	public int grade;
	public Student student;
	
//Constructor
//-----------------------------------------------------------------------------------------------------------------------------
	public Grade(int grade, Student student) {
		this.grade=grade;
		this.student=student;
	}
//------------------------------------------------------------------------------------------------------------------------------
		
		
//set methods
//------------------------------------------------------------------------------------------------------
	public void set_grade(int grade){	
		this.grade=grade;
	}
	
	public void set_Student(Student student){	
		this.student=student;
	}
//---------------------------------------------------------------------------------------------------------		
		
		
//get methods
//---------------------------------------------------------------------------------------------------------		
	public int get_grade() {
		return grade;
	}
	
	public Student get_Student() {
		return student;
	}
//---------------------------------------------------------------------------------------------------------		
	
	
}
