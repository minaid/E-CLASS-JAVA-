package Model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Random;
import java.util.Scanner;
import java.util.TimeZone;

public abstract class User {
	private int User_ID;
	private String Username;
	private String Password;
  	private String Name;
	private String Email;
	private Boolean Notification_enabled;
	private Boolean Is_Locked;
	private Boolean Is_Active;
	public  Department BelongToDepartment;
	private TimeZone GMT;
	private static int User_ID_Counter=0; //logika na mpei sto university + methodos pou au3anei to counter
	public List<Event> User_Events;           //user events
	public Boolean Is_Online;   
	public String[] Notifications;
	public int Notifications_Counter;
	public Date Date_Created;
	public int Phone;
	public String Country;
	public String City;
	public String Skype;
	public String LinkedIn;
	public String Custom_Section;
	public String Description;
	
//1st constructor
//-----------------------------------------------------------------------------------------------------------
	public User (String Username,String Password,String Email,String Name,Department BelongToDepartment){
		this.User_ID=User_ID_Counter + 1;
		this.Username=Username;
		this.Password=Password;
		this.Email=Email;
		this.Name=Name;
		this.Notification_enabled=true;
		this.Is_Locked=false;
		this.Is_Active=true;
		this.BelongToDepartment=BelongToDepartment;
		//this.GMT=GMT;	
	}
//-------------------------------------------------------------------------------------------------------------

//2nd constructor
//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	public User (String Username,String Password,String Email,String Name,Boolean Notification_enabled,Boolean Is_Locked,Boolean Is_Active,Department BelongToDepartment,TimeZone GMT,Boolean Is_Online){
		this.User_ID=User_ID_Counter + 1;
		User_ID_Counter+=1;
		this.Username=Username;
		this.Password=Password;
		this.Email=Email;
		this.Name=Name;
		this.Notification_enabled=Notification_enabled;
		this.Is_Locked=Is_Locked;
		this.Is_Active=Is_Active;
		this.BelongToDepartment=BelongToDepartment;
		this.GMT=GMT;
		this.Is_Online=Is_Online;
		User_Events=new ArrayList<Event>();
	}
//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

//To String
//-----------------------------------------------------------------------------------------------------------------------------------------------
	@Override
	public String toString(){
		return "Name:"+this.Name+" Username:"+this.Username+" Password:"+this.Password+" Email:"+this.Email+
		" Notification Enabled:"+this.Notification_enabled+" Active:"+this.Is_Active+" Locked:"+this.Is_Locked+" Department:"+this.BelongToDepartment+" Phone:"+this.Phone;
	}
//------------------------------------------------------------------------------------------------------------------------------------------------

//set methods
//-----------------------------------------------------------------------
	public void set_User_ID(int New_User_ID){
		this.User_ID=New_User_ID;
	}
	
	public void set_Name(String New_Name){
		this.Name=New_Name;
	}
	
	public void set_Username(String New_Username){
		this.Username=New_Username;
	}
	
	public void set_Password(String New_Password){
		this.Password=New_Password;
	}
	
	public void set_Email(String New_Email){
		this.Email=New_Email;
	}
	
	public void set_Notification_enabled(Boolean New_Notification_enabled){
		this.Notification_enabled=New_Notification_enabled;
	}
	
	public void set_Is_Locked(Boolean New_Is_Locked){
		this.Is_Locked=New_Is_Locked;
	}
	
	public void set_Is_Active(Boolean New_Is_Active){
		this.Is_Active=New_Is_Active;
	}
	
	public void set_BelongToDepartment(Department New_BelongToDepartment){
		this.BelongToDepartment=New_BelongToDepartment;
	}
	
	public void set_GMT(TimeZone New_GMT){
		this.GMT=New_GMT;
	}
	
	public void set_Is_Online(Boolean Is_Online){
		this.Is_Online=Is_Online;
	}
	
	public void set_Phone(int Phone){
		this.Phone=Phone;
	}
	
	public void set_Country(String Country){
		this.Country=Country;
	}
	
	public void set_City(String City){
		this.City=City;
	}
	
	public void set_Skype(String Skype){
		this.Skype=Skype;
	}
	
	public void set_LinkedIn(String LinkedIn){
		this.LinkedIn=LinkedIn;
	}
	
	public void set_Custom_Section(String Custom_Section){
		this.Custom_Section=Custom_Section;
	}
	
	public void set_Description(String Description){	
		this.Description=Description;
	}
	
	public void Add_Event(Event event)
	{
		this.User_Events.add(event);
	}
//----------------------------------------------------------------------



//get methods
//----------------------------------------------------------------------
	public int get_User_ID(){
		return User_ID;
	}
	
	public String get_Name(){
		return Name;
	}
	
	public String get_Username(){
		return Username;
	}
	
	public String get_Password(){
		return Password;
	}
	
	public String get_Email(){
		return Email;
	}
	
	public Boolean get_Notification_enabled(){
		return Notification_enabled;
	}
	
	public Boolean get_Is_Locked(){
		return Is_Locked;
	}
	
	public Boolean get_Is_Active(){
		return Is_Active;
	}
	
	public Department get_BelongToDepartment(){
		return BelongToDepartment;
	}
	
	public TimeZone get_GMT(){
		return GMT;
	}
	
	public Boolean get_Is_Online(){
		return Is_Online;
	}
	
	public Date get_Date_Created(){
		return Date_Created;
	}
	
	public int get_Phone(){
		return Phone;
	}
	
	public String get_Country(){
		return Country;
	}
	
	public String get_City(){
		return City;
	}
	
	public String get_Skype(){
		return Skype;
	}
	
	public String get_LinkedIn(){
		return LinkedIn;
	}
	
	public String get_Custom_Section(){
		return Custom_Section;
	}
	
	public	String get_Description(){
		return Description;
	}
//----------------------------------------------------------------------

	abstract void Temp();



//Login
//---------------------------------------------------------------------
	public void LogIn(){
		Scanner scan = new Scanner(System.in);
		Boolean right_choice=true;
		Boolean validation;
		int count_tries=0;
		User tmp_User=null;
		while (right_choice==true && count_tries<=3){
			System.out.println("Welcome to PAPI-Eclass! Please press 1 to enter or 2  in case you forgot your password. \n");
			String enter_choice= scan.nextLine();
			if(enter_choice=="1"){
				System.out.println("Username: \n");
				String Username= scan.nextLine();
				System.out.println("Password: \n");
				String Password= scan.nextLine();
				//validate
				 tmp_User=University.find_Current_User(Username);
				if(tmp_User.get_Is_Active()==false) {
					System.out.println("Account Inactive. \n");
					//scan.close();
					return;
				}
				if(tmp_User.get_Is_Locked()==true) {
					System.out.println("Your account is locked due to many login attempts. Please enter your email and request unlock. \n");
					String Email2= scan.nextLine();
					if(Email2!=null){                       //watch out for this condition, might not work wherever there is null
						Request_Unlock(tmp_User,Email2);
						System.out.println("Unlock account requested.We will make contact with as soon as possible. \n");
						//scan.close();
						return;
				}
				}
				validation=tmp_User.BelongToDepartment.Validate(tmp_User,Password);  //tha xreiastei allagi ? epidi exoume idi to xristi tmp_User
				if(validation==true){
					System.out.println("Welcome"+Username);
					right_choice=false;
				}else{
					System.out.println("Not valid credentials.Please retry. \n");
					System.out.println("Tries Left:"+ (3-count_tries));
					count_tries=count_tries+1;
				}
			}else if(enter_choice=="2"){
				//send email
				System.out.println("Please enter your email: \n");
				String Email= scan.nextLine();
				if(Email!=null){
				tmp_User.BelongToDepartment.Send_New_Password(Email);
				System.out.println("Password sent to:"+Email);
				System.out.println("Please retry to enter. \n");
				}
			}else{
				System.out.println("Not a supported choice.Please retry. \n");
			}
		}
		if(count_tries>3){
			//lock
			this.set_Is_Locked(true);
			System.out.println("Your account is locked due to many login attempts. Please enter your email and request unlock. \n");
			String Email2= scan.nextLine();
			if(Email2!=null){
				Request_Unlock(tmp_User,Email2);
				System.out.println("Unlock account requested.We will make contact with as soon as possible. \n");
			}
			//scan.close();
			return;
		}else{
			tmp_User.set_Is_Online(true);
			University.Home(University.find_Current_User(Username));  //tha mporousame tmp_User???
		}
		//scan.close();
		return;
	}
//----------------------------------------------------------------------------------------------



//Log Out
//--------------------------------------------------------------------------------
	public void LogOut(User Current_User){
		//end session
		Current_User.set_Is_Online(false);
		System.out.println(Current_User.Username+" Logged Out. \n");
		return;
		
	}
//---------------------------------------------------------------------------




//Search
//---------------------------------------------------------------------------
	public void Search(String Keyword){
		int count=0;
		for(int i=0;i<University.Department_counter;i++){
			for(int j=0;j<University.Departments[i].get_Users().size();j++){
				if(University.Departments[i].get_Users().get(j).Name.equals(Keyword)){
					System.out.println(University.Departments[i].get_Users().get(j).Name +" "+University.Departments[i].get_Users().get(j).Email +" "+University.Departments[i].get_Users().get(j).BelongToDepartment.Name +"\n");
					count=1;
				}
			}
			for(int g=0;g<University.Departments[i].get_Lessons().size();g++){
				if(University.Departments[i].get_Lessons().get(g).Name.equals(Keyword)){
					System.out.println(University.Departments[i].get_Lessons().get(g).Name +" "+University.Departments[i].get_Lessons().get(g).teacher.get_Name() +" "+University.Departments[i].get_Lessons().get(g).BelongToDepartment.Name +"\n");
					count=1;
				}	
			}
		}
		if(count==0) {
			System.out.println("The Keyword you entered was not a Lesson or User. \n");
		}
	}
//--------------------------------------------------------------------------



	
	public void Download_File(){}  //na mpei file pedio sto user
	
	public void Upload_File(){}
	
	public void Get_Help(){}
	
	public void Calendar(){}
	
	




//Create Event
//---------------------------------------------------------
	public void Create_Event(User Current_User){          //mandatory fields
		Event New_Event=new Event();
		Scanner scan = new Scanner(System.in);
		System.out.println("Name: \n");
		String name= scan.nextLine();
		New_Event.set_Name(name);
		//System.out.println("Date Ending: \n");             //validation gia date???
		//String date_ending= scan.nextLine();
		//New_Event.set_Date_Ending(date_ending);
		System.out.println("Place: \n");
		String place= scan.nextLine();
		New_Event.set_Place(place);
		//scan.close();
		Current_User.Add_Event(New_Event);
		System.out.println("Event Created. \n");
		return;
	}
//------------------------------------------------------------





//public void Cancel_Event(){}






//Edit Event
//-----------------------------------------------------------------------
	public void Edit_Event(User Current_User,Event Current_Event){
		Boolean break_big_loop=false;
		Boolean reminder=false;
		Boolean status=false;                           //need to check the value initialized
		Scanner scan = new Scanner(System.in);
		while(break_big_loop==false){
		System.out.println("Press 1 to change the Name\n"+
						   "Press 2 to change the Ending Date\n"+
						   "Press 3 to change the Place \n"+
						   "Press 4 to change the Description\n"+
						   "Press 5 to change the Reminder\n"+
						   "Press 6 to change the Status\n"+
						   "Press 7 to change the Users Invited\n"+
						   "Press 8 to Exit\n");
		int option= scan.nextInt();
		if(option==1){
			System.out.println("Name: \n");
			String name= scan.nextLine();
			name= scan.nextLine();
			Current_Event.set_Name(name);
		}else if(option==2){
			System.out.println("Date Ending: \n");             //validation gia date???
			String date_ending= scan.nextLine();
			date_ending= scan.nextLine();
			Current_Event.set_Date_Ending(date_ending);
		}else if(option==3){
			System.out.println("Place: \n");
			String place= scan.nextLine();
			place= scan.nextLine();
			Current_Event.set_Place(place);
		}else if(option==4){
			System.out.println("Description: \n");
			String description= scan.nextLine();
			description= scan.nextLine();
			Current_Event.set_Description(description);
		}else if(option==5){
			Boolean break_loop=false;
			while(break_loop==false){
			System.out.println("Press 1 for enable reminder and 2 for disable reminder \n");
			System.out.println("Reminder: \n");
			int reminder_option= scan.nextInt();
			if (reminder_option==1){
				reminder=true;
				break_loop=true;
			}else if (reminder_option==2){
				reminder=false;
				break_loop=true;
			}
			else{
				System.out.println("Not an available option.Please retry. \n");
			}
			}
			Current_Event.set_Reminder(reminder);
		}else if(option==6){
			Boolean break_loop2=false;
			while(break_loop2==false){
			System.out.println("Press 1 for Event Status:Active , 2 for Event Status:Cancelled \n");
			System.out.println("Status: \n");
			int status_option= scan.nextInt();
			if (status_option==1){
				status=true;
				break_loop2=true;
			}else if (status_option==2){
				status=false;
				break_loop2=true;
			}
			else{
				System.out.println("Not an available option.Please retry. \n");
			}
			}
			Current_Event.set_Status(status);
		}else if(option==7){
			Boolean while_again=false;
			int counter_users=0;
			int tmp_users_counter=0;
			User[] tmp_users=new User[1000];   //tha xreiastei allagi???
			Boolean choose_user=false;
			System.out.println("Users Invited: \n");
			for(int i=0;i<Current_Event.Users_Invited_Counter;i++){
				System.out.println(Current_Event.Users_Invited[i].Name + "\n");
				System.out.println(Current_Event.Users_Invited[i].Email + "\n");
			}
			Boolean break_loop3=false;
			while(break_loop3==false) {
				while_again=false;
				choose_user=false;
			System.out.println("Press 1 for Invite a User , 2 for Uninvite a User, 3 for Exit option: \n");
			int invite_option= scan.nextInt();
			if (invite_option==1){
				System.out.println("Users Available to invite: \n");
				if(Current_User instanceof Student){
					for(int i=0;i<((Student) Current_User).get_Friends().size();i++){
						for(int j=0;j<Current_Event.Users_Invited_Counter;j++){
							if(Current_Event.Users_Invited[j].User_ID==((Student) Current_User).get_Friends().get(i).get_User_ID()){
								counter_users=1;
							}
								
						}
						if(counter_users==0){
						System.out.println(((Student) Current_User).get_Friends().get(i).get_Name() + "\n");
						System.out.println(((Student) Current_User).get_Friends().get(i).get_Email() + "\n");
						tmp_users[tmp_users_counter]=((Student) Current_User).get_Friends().get(i);
						tmp_users_counter=tmp_users_counter+1;
						}
						counter_users=0;
					}
					 Boolean choose_all=false;
					while (choose_all==false){
					System.out.println("Choose users, if you want to invite all press 1 or press 2 for selected users. \n");
					int choose_all_choice= scan.nextInt();
					if(choose_all_choice==1) {
						for(int w=0;w<tmp_users_counter;w++){
								Invite(tmp_users[w]);                                //ulopoiisi xreiazetai?
								//Current_Event.Users_Invited.add(tmp_users[w]);
								Current_Event.set_Users_Invited(tmp_users[w]);              //douleuei to tmp_users i xreiazetai to find_user???
								System.out.println("User "+tmp_users[w].Name+" invited. \n");
						}
						choose_all=true;
					}
					else if(choose_all_choice==2) {
					while(choose_user==false){
					System.out.println("Choose users, enter Name of User: \n");
					String invite_user= scan.nextLine();
					System.out.println("Choose users, enter Email of User: \n");
					String invite_user_email= scan.nextLine();
					for(int w=0;w<tmp_users_counter;w++){
						if(invite_user.equals(tmp_users[w].Name) && invite_user_email.equals(tmp_users[w].Email)){
							Invite(tmp_users[w]);                                //ulopoiisi xreiazetai?
							//Current_Event.Users_Invited.add(tmp_users[w]);
							Current_Event.set_Users_Invited(tmp_users[w]);              //douleuei to tmp_users i xreiazetai to find_user???
							System.out.println("User "+tmp_users[w].Name+" invited. \n");
						}else{
							System.out.println("User "+tmp_users[w].Name+" is already invited or does not exist. \n");
						}
					}
					while(while_again==false && choose_all==false){
					System.out.println("Invite another User? Press 1 for Yes, 2 for No \n");
					int invite_option2= scan.nextInt();
					if(invite_option2==2){
						choose_user=true;
						while_again=true;
					}else if(invite_option2==1){
						while_again=true;
						continue;
					}else{
						System.out.println("Not an available option.Please retry. \n");
					}
					}
					}
					choose_all=true;
				}else {
					System.out.println("Not an available option.Please retry. \n");
					}
					}
				}else {   //teacher and secretariat
					for(int i=0;i<Current_User.BelongToDepartment.get_Users().size();i++){
						for(int j=0;j<Current_Event.Users_Invited_Counter;j++){
							if(Current_Event.Users_Invited[j].User_ID==Current_User.BelongToDepartment.get_Users().get(i).User_ID){
								counter_users=1;
							}
								
						}
						if(counter_users==0){
						System.out.println(Current_User.BelongToDepartment.get_Users().get(i).Name + "\n");
						System.out.println(Current_User.BelongToDepartment.get_Users().get(i).Email + "\n");
						tmp_users[tmp_users_counter]=Current_User.BelongToDepartment.get_Users().get(i);
						tmp_users_counter=tmp_users_counter+1;
						}
						counter_users=0;
					}
					Boolean choose_all=false;
					while (choose_all==false){
					System.out.println("Choose users, if you want to invite all press 1 or press 2 for selected users. \n");
					int choose_all_choice= scan.nextInt();
					if(choose_all_choice==1) {
						for(int w=0;w<tmp_users_counter;w++){
								Invite(tmp_users[w]);                                //ulopoiisi xreiazetai?
								//Current_Event.Users_Invited.add(tmp_users[w]);
								Current_Event.set_Users_Invited(tmp_users[w]);              //douleuei to tmp_users i xreiazetai to find_user???
								System.out.println("User "+tmp_users[w].Name+" invited. \n");
						}
						choose_all=true;
					}
					else if(choose_all_choice==2) {
					while(choose_user==false){
					System.out.println("Choose users, enter Name of User: \n");
					String invite_user= scan.nextLine();
					System.out.println("Choose users, enter Email of User: \n");
					String invite_user_email= scan.nextLine();
					for(int w=0;w<tmp_users_counter;w++){
						if(invite_user.equals(tmp_users[w].Name) && invite_user_email.equals(tmp_users[w].Email)){
							Invite(tmp_users[w]);     //ulopoiisi xreiazetai?
							//Current_Event.Users_Invited.add(tmp_users[w]);
							Current_Event.set_Users_Invited(tmp_users[w]);              //douleuei to tmp_users i xreiazetai to find_user???
							System.out.println("User "+tmp_users[w].Name+" invited. \n");
						}else{
							System.out.println("User "+tmp_users[w].Name+" is already invited or does not exist. \n");
						}
					}
					while(while_again==false && choose_all==false){
					System.out.println("Invite another User? Press 1 for Yes, 2 for No \n");
					int invite_option2= scan.nextInt();
					if(invite_option2==2){
						choose_user=true;
						while_again=true;
					}else if(invite_option2==1){
						while_again=true;
						continue;
					}else{
						System.out.println("Not an available option.Please retry. \n");
					}
					}
					}
					choose_all=true;
					}
					else {
						System.out.println("Not an available option.Please retry. \n");
						}
					}
				}
				
				
				//status=true;
				//break_loop3=true;
			}else if (invite_option==2){
				//while?
					choose_user=false;
					while_again=false;
					while(choose_user==false){
					System.out.println("Choose users to Uninvite, enter Name of User: \n");
					String invite_user= scan.nextLine();
					System.out.println("Choose users to Uninvite, enter Email of User: \n");
					String invite_user_email= scan.nextLine();
					for(int w=0;w<Current_Event.Users_Invited_Counter;w++){
						if(invite_user.equals(Current_Event.Users_Invited[w].Name) && invite_user_email.equals(Current_Event.Users_Invited[w].Email)){
							Uninvite(Current_Event.Users_Invited[w]);                                   //ulopoiisi xreiazetai?
							//Current_Event.Users_Invited.remove(Current_Event.Users_Invited[w]);
							Current_Event.set_Users_Uninvited(tmp_users[w]);              //douleuei to tmp_users i xreiazetai to find_user???
							System.out.println("User "+Current_Event.Users_Invited[w].Name+" uninvited. \n");
						}else{
							System.out.println("User "+Current_Event.Users_Invited[w].Name+" is not invited or does not exist. \n");
						}
					}
					while(while_again==false){
					System.out.println("Uninvite another User? Press 1 for Yes, 2 for No \n");
					int invite_option2= scan.nextInt();
					if(invite_option2==2){
						choose_user=true;
						while_again=true;
					}else if(invite_option2==1){
						while_again=true;
						continue;
					}else{
						System.out.println("Not an available option.Please retry. \n");
					}
					}
					}
				
				//status=false;
				//break_loop3=true;
			}else if (invite_option==3){
				//status=false;
				break_loop3=true;
			}
			else{
				System.out.println("Not an available option.Please retry. \n");
			}
			}
		
		}else if(option==8){
			break_big_loop=true;
			System.out.println("Exit.");
			//scan.close();
			return;
		}else{
			System.out.println("Not an available option.Please retry. \n");
		}
		}
		//scan.close();
		return;
	}
//----------------------------------------------------------------------------------


//View User Online
//-----------------------------------------------------------------------------------
	public void View_Users_Online(){
		System.out.println("Users Online: \n");
		for(int i=0;i<University.Department_counter;i++) {
			for(int j=0;j<University.Departments[i].get_Users().size();j++) {
				if(University.Departments[i].get_Users().get(j).get_Is_Online()==true) {
					System.out.println(University.Departments[i].get_Users().get(j).get_Name()+"\n");
				}
			}
		}
		return;
	}
//-------------------------------------------------------------------------------------


//Edit Event Invitation
//-------------------------------------------------------------------------------------
	public void Edit_EventInvitation(User Current_User, Event event){
		int choose;
		Boolean whileloop=false;
		Scanner scan = new Scanner(System.in);
		for (int i=0;i<Current_User.User_Events.size();i++) {
			if(Current_User.User_Events.get(i).equals(event)) {
				while(whileloop==false) {
				System.out.println("Respond to Invitation: "+ event.Name + " Press 0 for Accept, 1 for Reject, 2 for Exit \n");          //na vgainei kai apo to users_invited
				choose= scan.nextInt();
				if(choose==0) {
				Current_User.User_Events.get(i).set_Users_Accepted(Current_User);
				//scan.close();
				return;
				}
				else if(choose==1){
				Current_User.User_Events.get(i).set_Users_Rejected(Current_User);
				//scan.close();
				return;
				}else if(choose==2) {
					//scan.close();
					return;
				}else {
					System.out.println("Not an available option.Please retry. \n");
				}
				}
			}
		}
		//scan.close();
		return;
	}
//-------------------------------------------------------------------------------------


//View Events
//------------------------------------------------------------------------------------
	public void View_Events(User Current_User){
		System.out.println("User events: \n");
		for(int i=0;i<Current_User.User_Events.size();i++) {
			System.out.println(Current_User.User_Events.get(i).Name + "\n");
		}
		return;
	}
//------------------------------------------------------------------------------------

//Send Message
//------------------------------------------------------------------------------------
	public void Send_Message(User Current_User, User tosend){                           //somewhere we should select the user
		System.out.println("Please enter message to user "+ tosend.Name +" : \n");  
		Scanner scan = new Scanner(System.in);
		String strmessage= scan.nextLine();
		int counter=0;
		for(int i=0;i<University.Messages_Counter;i++) {
			for(int j=0;j<University.Messages[i].User_Counter;j++) {
				if(Current_User==University.Messages[i].Users[j]) {
					counter=counter+1;
				}
				if(tosend==University.Messages[i].Users[j]) {
					counter=counter+1;
				}
			}
			if(counter==2) {
				University.Messages[i].message[University.Messages[i].Message_Counter]=strmessage;
				University.Messages[i].Message_Counter=University.Messages[i].Message_Counter+1;
				//scan.close();
				return;
			}
		}
		if(counter==0) {
			University.Messages[University.Messages_Counter]=new Message();
			University.Messages[University.Messages_Counter].message[University.Messages[University.Messages_Counter].Message_Counter]=strmessage;
			University.Messages[University.Messages_Counter].Message_Counter=University.Messages[University.Messages_Counter].Message_Counter+1;
			University.Messages[University.Messages_Counter].Users[University.Messages[University.Messages_Counter].User_Counter]=Current_User;
			University.Messages[University.Messages_Counter].User_Counter=University.Messages[University.Messages_Counter].User_Counter+1;
			University.Messages[University.Messages_Counter].Users[University.Messages[University.Messages_Counter].User_Counter]=tosend;
			University.Messages[University.Messages_Counter].User_Counter=University.Messages[University.Messages_Counter].User_Counter+1;
			//scan.close();
			return;
		}
		
		//scan.close();
		return;
	}
//------------------------------------------------------------------------------------


//View Message History
//------------------------------------------------------------------------------------
	public void View_Message_History(User Current_User, User tosend){
		 int counter=0;
		 for(int i=0;i<University.Messages.length;i++) {
			 for(int j=0;j<University.Messages[i].Users.length;j++) {
				 if(Current_User==University.Messages[i].Users[j]) {
					 counter=counter+1;
				 }
				 if(tosend==University.Messages[i].Users[j]) {
					 counter=counter+1;
				 }
			 }
			 if(counter==2) {
				 for(int w=0;w<University.Messages[i].message.length;w++) {
					 if(University.Messages[i].message[w]!=null) {
					 System.out.println("Messages: \n");
					 System.out.println(University.Messages[i].message[w] +" \n");
				 }
				 }
				 return;
			}
		 }
		 System.out.println("No Messages. \n");
		return;
	}
//------------------------------------------------------------------------------------


//View Announcements
//-----------------------------------------------------------------------------------
	public void View_Department_Announcements(User Current_User){
		
		System.out.println("Department Announcements: \n");
		for(int i=0;i<Current_User.BelongToDepartment.get_Announcements().size();i++) {
			System.out.println(Current_User.BelongToDepartment.get_Announcements().get(i).Title +" \n");
			System.out.println(Current_User.BelongToDepartment.get_Announcements().get(i).Description +" \n");
			System.out.println(Current_User.BelongToDepartment.get_Announcements().get(i).date +" \n");
			for(int j=0;j<Current_User.BelongToDepartment.get_Announcements().get(i).Comments_Counter;j++) {
				System.out.println(Current_User.BelongToDepartment.get_Announcements().get(i).Comments[j] +" \n");
			}
			
		}
		return;
		
	}
//-----------------------------------------------------------------------------------

//Comment
//-----------------------------------------------------------------------------------
	public void Comment(Announcement announcement){
		System.out.println("Please enter comment: \n");  
		Scanner scan = new Scanner(System.in);
		String comment= scan.nextLine();
		announcement.Comments[announcement.Comments_Counter]=comment;
		announcement.Comments_Counter=announcement.Comments_Counter+1;
		//scan.close();
		return;
		
		
	}
//-----------------------------------------------------------------------------------

//Edit Comment
//-----------------------------------------------------------------------------------
	public void Edit_Comment(Announcement announcement, int comment_position){
		System.out.println("Please enter to edit comment: \n");  
		Scanner scan = new Scanner(System.in);
		String comment= scan.nextLine();
		announcement.Comments[comment_position]=comment;
		//scan.close();
		return;
	}
//-----------------------------------------------------------------------------------


//View Lesson Announcement
//-----------------------------------------------------------------------------------
	public void View_Lesson_Announcements(User Current_User, Lesson lesson){
		System.out.println("Department Announcements: \n");
		for(int i=0;i<lesson.Lesson_Announcements_Counter;i++) {
			System.out.println(lesson.Lesson_Announcements[i].Title +" \n");
			System.out.println(lesson.Lesson_Announcements[i].Description +" \n");
			System.out.println(lesson.Lesson_Announcements[i].date +" \n");
			for(int j=0;j<Current_User.BelongToDepartment.get_Announcements().get(i).Comments_Counter;j++) {
				System.out.println(lesson.Lesson_Announcements[i].Comments[j] +" \n");
			}
			
		}
		return;
	}
//----------------------------------------------------------------------------------



//View User Profile
//----------------------------------------------------------------------------------
	public void View_User_Profile(User user){     //toString?
		System.out.println("User: \n");
		System.out.println(user.Name +" \n");
		System.out.println(user.Email +" \n");
		System.out.println(user.BelongToDepartment.Name +" \n");
		if(user.Is_Online==true) {
			System.out.println("Status: Online \n");
		}else {
			System.out.println("Status: Offline \n");
		}  
		return;
	} 
//----------------------------------------------------------------------------------


//View Notifications
//----------------------------------------------------------------------------------   //need to enter somewhere the notifications of the user
	public void View_Notifications(User Current_User){
		System.out.println("Your Notifications: \n");
		for(int i=0;i<Current_User.Notifications_Counter;i++) {
			System.out.println(Current_User.Notifications[i]+" \n");
		}
		return;
	}
//----------------------------------------------------------------------------------



//View My Profile
//----------------------------------------------------------------------------------
	public void View_My_Profile() {
		System.out.println("Current Username: "+ Username+" \n");
		System.out.println("Current Email: "+ Email+" \n");
		System.out.println("Notifications Enabled: "+ Notification_enabled+" \n");
		System.out.println("Current Department: "+ BelongToDepartment+" \n");
		System.out.println("Current GMT: "+ GMT+" \n");
		System.out.println("Date Created: "+ Date_Created+" \n");
		System.out.println("Current Phone: "+ Phone+" \n");
		System.out.println("Current Country: "+ Country+" \n");
		System.out.println("Current City: "+ City+" \n");
		System.out.println("Current Skype: "+ Skype+" \n");
		System.out.println("Current LinkedIn: "+ LinkedIn+" \n");
		System.out.println("Custom Section: "+ Custom_Section+" \n");
		System.out.println("Description: "+ Description+" \n");
		System.out.println("Name: "+ Name+" \n");
	}
//----------------------------------------------------------------------------------



//Edit Profile
//----------------------------------------------------------------------------------
	public void Edit_Profile(User Current_User){	
		Boolean break_big_loop=false;
		Boolean status=false;                           //need to check the value initialized
		Scanner scan = new Scanner(System.in);
		while(break_big_loop==false){
		System.out.println("Press 1 to change the Username\n"+
						   "Press 2 to change the Password\n"+
						   "Press 3 to change the Email\n"+
						   "Press 4 to change the Notification Enable\n"+
						   "Press 5 to change the GMT\n"+
						   "Press 6 to Exit\n");
		int option= scan.nextInt();
		if(option==1){
			System.out.println("Current Username: "+ Current_User.Username+" \n");
			System.out.println("New Username: \n");
			String name= scan.nextLine();
			name= scan.nextLine();
			Current_User.set_Username(name);
			System.out.println("Changes made. \n");
		}else if(option==2){
			System.out.println("Current Password: "+ Current_User.Password+" \n");
			System.out.println("New Password: \n");
			String password= scan.nextLine();
			password= scan.nextLine();
			Current_User.set_Password(password);
			System.out.println("Changes made. \n");
		}else if(option==3){
			System.out.println("Current Email: "+ Current_User.Email+" \n");
			System.out.println("New Email: \n");
			String email= scan.nextLine();
			email= scan.nextLine();
			Current_User.set_Email(email);
			System.out.println("Changes made. \n");
		}else if(option==4){
			if(Current_User.Notification_enabled==true) {
				System.out.println("Notification Enabled: Yes \n");
			}else {
				System.out.println("Notification Enabled: No \n");
			}
			Boolean break_loop2=false;
			while(break_loop2==false){
			System.out.println("Press 1 for Notification Enabled: Yes , 2 for Notification Enabled: No \n");
			System.out.println("Enter Choice: \n");
			int status_option= scan.nextInt();
			if (status_option==1){
				status=true;
				break_loop2=true;
			}else if (status_option==2){
				status=false;
				break_loop2=true;
			}
			else{
				System.out.println("Not an available option.Please retry. \n");
			}
			}
			Current_User.set_Notification_enabled(status);
			System.out.println("Changes made. \n");
		}else if(option==5){
			System.out.println("Current GMT: "+ Current_User.GMT+" \n");               //change GMT???
			//System.out.println("New GMT: \n");
			//String email= scan.nextLine();
			//Current_User.set_Email(email);
			//System.out.println("Changes made. \n");
		}else if(option==6){
			break_big_loop=true;
			System.out.println("Exit.");
			//scan.close();
			//return;
		}else{
			System.out.println("Not an available option.Please retry. \n");
		}
		}
		//scan.close();
		return;
	}
//----------------------------------------------------------------------------------



//Request Unlock
//----------------------------------------------------------------
	public void Request_Unlock(User tmp_User,String Email){
			if(Email.equals(tmp_User.get_Email())){
				Send_Email_Unlock(Email,tmp_User.get_Username());
				return;
			}
		System.out.println("No such email exists. Please retry. \n");
		return;
		
	}
//----------------------------------------------------------------



//Send Email
//-------------------------------------------------------------------------------------
	public void Send_Email_Unlock(String Email,String Username){
		/*
		// Recipient's email ID needs to be mentioned.
	      String to = "n.minaidis@sdfsd.com";
	
	      // Sender's email ID needs to be mentioned
	      String from = "web@gmail.com";
	
	      // Assuming you are sending email from localhost
	      String host = "localhost";
	
	      // Get system properties
	      Properties properties = System.getProperties();
	
	      // Setup mail server
	      properties.setProperty("mail.smtp.host", host);
	
	      // Get the default Session object.
	      Session session = Session.getDefaultInstance(properties);
	
	      try {
	         // Create a default MimeMessage object.
	         MimeMessage message = new MimeMessage(session);
	
	         // Set From: header field of the header.
	         message.setFrom(new InternetAddress(from));
	
	         // Set To: header field of the header.
	         message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
	
	         // Set Subject: header field
	         message.setSubject("Unlock Requested");
	
	         // Now set the actual message
	         message.setText("For User: "+Username+" With Email: "+Email);
	
	         // Send message
	         Transport.send(message);
	         System.out.println("Unlock requested successfully. \n");
	      } catch (MessagingException mex) {
	         mex.printStackTrace();
	      }
	      */
	}	
//---------------------------------------------------------------------------------



//Invite
//---------------
	void Invite(User user) {
		
	}
//--------------



//Uninvite
//---------------
	void Uninvite(User user) {
		
	}
//--------------

}
