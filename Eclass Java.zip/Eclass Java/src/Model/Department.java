package Model;

import java.util.*;
import java.util.Properties;
import java.util.Random;

public class Department {

	public int Department_ID;
	private static int Department_ID_Counter=0;
	public String Name;
	//private  User[] Users;               // i alliws Student[] kai Teacher[]
	//private  Lesson[] Lessons;
	//private  Announcement[] Announcements;
	private List<Student> Students;
	private List<Teacher> Teachers;
	private List<Lesson> Lessons;
	private List<Announcement> Announcements;
	public int Announcement_Counter;
	public String Description;
	public Secretariat secretariat;
	
	
//Constructor
//-------------------------------------------------------------------------------------
	public Department (String Name){      
		this.Department_ID=Department_ID_Counter + 1;
		this.Name=Name;
		this.Students=new ArrayList<Student>();
		this.Teachers=new ArrayList<Teacher>();
		this.Lessons=new ArrayList<Lesson>();
		this.Announcements=new ArrayList<Announcement>();
	}
//---------------------------------------------------------------------------------------


//set methods
//------------------------------------------------------------------------------------------------------

	public void Add_Student(Student student)
	{
		this.Students.add(student);
	}
	
	public void Add_Teacher(Teacher teacher)
	{
		this.Teachers.add(teacher);
	}
	
	public void Add_Lesson(Lesson lesson){	
		this.Lessons.add(lesson);

	}
	
	public void set_Announcements(Announcement announcement){	
		this.Announcements.add(announcement);
		this.Announcement_Counter=this.Announcement_Counter+1;
	}
	
	public void set_Name(String Name){	
		this.Name=Name;
	}
	
	public void set_Description(String Description){	
		this.Description=Description;
	}
	
	public void set_Secretariat(Secretariat secretariat){	
		this.secretariat=secretariat;
	}
//---------------------------------------------------------------------------------------------------------


//get methods
//---------------------------------------------------------------------------------------------------------
	public List<Student> get_Students(){
		return Students;
	}
	public List<Teacher> get_Teachers()
	{
		return Teachers;
	}
	
	public List<User> get_Users()
	{
		List<User> users=new ArrayList<User>();
		users.addAll(Students);
		users.addAll(Teachers);
		users.add(secretariat);
		return users;
	}
	
	public List<Lesson> get_Lessons(){
		return Lessons;
	}
	
	public List<Announcement> get_Announcements(){
		return Announcements;
	}
	
	public String get_Name() {
		return Name;
	}
	
	public String get_Description() {
		return Description;
	}
	
	public Secretariat get_Secretariat() {
		return secretariat;
	}
//---------------------------------------------------------------------------------------------------------
		
	
	
//Validate	
//-----------------------------------------------------------------------------------------	
	public Boolean Validate(User user,String Password){
		
		
		if(user.get_Password().equals(Password))
			return true;
		return false;
		
		/*
		User user;
		for(int i=0;i<Students.size();i++){
			user=Students.get(i);
			if(Username==user.get_Username() && Password==user.get_Password()){
				return true;
			}
		}
		for(int i=0;i<Teachers.size();i++){
			user=Teachers.get(i);
			if(Username==user.get_Username() && Password==user.get_Password()){
				return true;
			}
		}
		if(Username==secretariat.get_Username()&&Password==secretariat.get_Password())
			return true;
		return false;*/
	}
//-----------------------------------------------------------------------------------------


//Send New Password
//---------------------------------------------------------------------------------------
	public void Send_New_Password(String Email){
		User user;
		for(int i=0;i<Students.size();i++){
			user=Students.get(i);
			if(Email.equals(user.get_Email())){
				user.set_Password(getSaltString());
				Send_Email(Email,user.get_Password());
				return;
			}
		}
		for(int i=0;i<Teachers.size();i++){
			user=Teachers.get(i);
			if(Email.equals(user.get_Email())){
				user.set_Password(getSaltString());
				Send_Email(Email,user.get_Password());
				return;
			}
		}
		user=secretariat;
		if(Email.equals(user.get_Email())){
			user.set_Password(getSaltString());
			Send_Email(Email,user.get_Password());
			return;
		}
		System.out.println("No such email exists. Please retry.");
		return;
	}
//---------------------------------------------------------------------------------------


//Random Password
//----------------------------------------------------------------------------------------
	protected String getSaltString() {
	    String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
	    StringBuilder salt = new StringBuilder();
	    Random rnd = new Random();
	    while (salt.length() < 18) { // length of the random string.
	        int index = (int) (rnd.nextFloat() * SALTCHARS.length());
	        salt.append(SALTCHARS.charAt(index));
	    }
	    String saltStr = salt.toString();
	    return saltStr;
	}
//-----------------------------------------------------------------------------------------


//Send Email
//--------------------------------------------------------------------------------------
	public void Send_Email(String Email,String Password){
		
		/*
	// Recipient's email ID needs to be mentioned.
	  String to = Email;
	
	  // Sender's email ID needs to be mentioned
	  String from = "web@gmail.com";
	
	  // Assuming you are sending email from localhost
	  String host = "localhost";
	
	  // Get system properties
	  Properties properties = System.getProperties();
	
	  // Setup mail server
	  properties.setProperty("mail.smtp.host", host);
	
	  // Get the default Session object.
	  Session session = Session.getDefaultInstance(properties);
	
	  try {
	     // Create a default MimeMessage object.
	     MimeMessage message = new MimeMessage(session);
	
	     // Set From: header field of the header.
	     message.setFrom(new InternetAddress(from));
	
	     // Set To: header field of the header.
	     message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
	
	     // Set Subject: header field
	     message.setSubject("New Password Requested");
	
	     // Now set the actual message
	     message.setText("This is your new password: "+Password);
	
	     // Send message
	     Transport.send(message);
	     System.out.println("Password sent successfully to: "+Email);
	  } catch (MessagingException mex) {
	     mex.printStackTrace();
	  }
	  */
	}	
//--------------------------------------------------------------------------------------	
	
//Create User
//--------------------------------------------------------------------------------------
	//public void Create_User(String Name)
	//{
	//	User cr_user=new Student(Announcement_Counter, Name, Name, Name, Name, null, null, null, null, null);       //needs improvement
	//}
//---------------------------------------------------------------------------------------
	
}
