package Model;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Event {

	public int Event_ID;
	private static int Event_ID_Counter=0;
	public String Name;
	public String Place;
	public Date Date_Ending;
	public Date Date_Starting;
	public String Description;
	public Boolean Reminder;
	public Boolean Status;
	public User[] Users_Invited;
	public int Users_Invited_Counter=0;
	public User[] Users_Accepted;
	public int Users_Accepted_Counter=0;
	public User[] Users_Rejected;
	public int Users_Rejected_Counter=0;
	public User User_Created;

//Constructor
//-------------------------------------------------------------------------------------
	public Event() {
		
	}
	
	public Event (String Name, String Place,Date Date_Ending, String Description, Boolean Reminder, Boolean Status,Date Date_Starting){               //i Message(User[] Users,String[] message)
		this.Event_ID=Event_ID_Counter + 1;
		this.Name=Name;
		this.Place=Place;
		this.Date_Ending=Date_Ending;
		this.Description=Description;
		this.Reminder=Reminder;
		this.Status=Status;
		this.Date_Starting=Date_Starting;
	}
//---------------------------------------------------------------------------------------


//set methods
//------------------------------------------------------------------------------------------------------
	void set_Name(String Name) {
		this.Name=Name;
	}
	
	void set_Place(String Place) {
		this.Place=Place;
	}
	
	void set_Users_Invited(User user) {
		this.Users_Invited_Counter=this.Users_Invited_Counter+1;
		this.Users_Invited[this.Users_Invited_Counter]=user;
	}

	void set_Users_Uninvited(User user) {
		//Users_Invited_Counter=Users_Invited_Counter+1;
		for(int i=0;i<this.Users_Invited_Counter;i++) {
			if (user.get_User_ID()==this.Users_Invited[i].get_User_ID()) {
				this.Users_Invited[i]=null; //CHECK FOR BUGS
			}
		}
	}

	void set_Users_Accepted(User user) {
		this.Users_Accepted_Counter=this.Users_Accepted_Counter+1;
		this.Users_Accepted[this.Users_Accepted_Counter]=user;
		for(int i=0;i<this.Users_Rejected_Counter;i++) {
			if (user.get_User_ID()==this.Users_Rejected[i].get_User_ID()) {
				this.Users_Rejected[i]=null;//CHECK FOR BUGS
			}
		}
	}

	void set_Users_Rejected(User user) {
		this.Users_Rejected_Counter=this.Users_Rejected_Counter+1;
		this.Users_Rejected[this.Users_Rejected_Counter]=user;
		for(int i=0;i<this.Users_Accepted_Counter;i++) {
			if (user.get_User_ID()==this.Users_Accepted[i].get_User_ID()) {
				this.Users_Accepted[i]=null;//CHECK FOR BUGS
			}
		}
	}

	void set_Date_Ending(String Date_Ending) {
		DateFormat format = new SimpleDateFormat("MMMM d, yyyy", Locale.ENGLISH);
		try {
			 this.Date_Ending = format.parse(Date_Ending);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	void set_Date_Starting(String Date_Starting) {
		DateFormat format = new SimpleDateFormat("MMMM d, yyyy", Locale.ENGLISH);
		try {
			 this.Date_Starting = format.parse(Date_Starting);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	void set_Status(Boolean Status) {
		this.Status=Status;
	}

	void set_Reminder(Boolean Reminder) {
		this.Reminder=Reminder;
	}

	void set_Description(String Description) {
		this.Description=Description;
	}
	
	void set_User_Created(User User_Created) {
		this.User_Created=User_Created;
	}
//---------------------------------------------------------------------------------------------------------


//get methods
//---------------------------------------------------------------------------------------------------------
	public String get_Name(){
		return Name;
	}
	
	public String get_Place(){
		return Place;
	}
	
	public String get_Description(){
		return Description;
	}
	
	public Boolean get_Status(){
		return Status;
	}
	
	public Boolean get_Reminder(){
		return Reminder;
	}
	
	public Date get_Date_Starting(){
		return Date_Starting;
	}
	
	public Date get_Date_Ending(){
		return Date_Ending;
	}
	
	public User[] Users_Invited() {
		return Users_Invited;
	}
	
	public User[] Users_Accepted() {
		return Users_Accepted;
	}
	
	public User[] Users_Rejected() {
		return Users_Rejected;
	}
	
	public User User_Created() {
		return User_Created;
	}
//---------------------------------------------------------------------------------------------------------
}